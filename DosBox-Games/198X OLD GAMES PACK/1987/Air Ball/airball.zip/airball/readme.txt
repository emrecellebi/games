Downloaded from http://www.classicpcgames.com

Come and see for yourself!!!