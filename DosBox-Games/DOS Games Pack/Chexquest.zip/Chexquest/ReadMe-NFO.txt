Chex Quest
Developed by: Digital Cafe
Published by: Freeware
Presented by: Home of the Underdogs (www.the-underdogs.org)
Repacked by: doowopman

Here's a nice, easy-to-install repacked version of
Chex Quest :).  this is a pretty nifty and very
unique Doom mod. 

To install the game, just run chexquest.exe  The 
RAR's will begin unpacking automatically.  To set
up your soundcard, run setup.exe  To start the game
you can either run chex.exe or chex1.bat

The game works fine under a Windows 95/98 DOS box. As
always, if you have trouble with this try running the
game in pure DOS.  Compatibilty with Windows Me/NT/2k/XP
is not guaranteed.  If you have any technical problems, 
please post in the tech help forum (www.the-underdogs.org/forum).

Enjoy the game 8-)!