Readme Chicken Invaders
      DX edition
      Version 1.01
      Copyright � 1999 Konstantinos Prouskas / InterAction software



       
      CONTENTS



        Introduction
        Requirements
        Playing the game
        Troubleshooting
        Contact information
        Acknowledgements

       
      INTRODUCTION



        Welcome to Chicken Invaders!
        Earth is being invaded by chickens from another galaxy, bent on revenge 
        against the human race for its oppression of earth chickens! You are the 
        only one standing in the way of total annihilation of the human race! 
        The future of chicken burgers is in your hands! 
       
      REQUIREMENTS



        Minimum Configuration
        Microsoft Windows 95/98/2000
        Pentium-class processor
        16MB RAM - 8MB free
        Graphics card capable of 640x480x16bit color.
        DirectX 7.0 (or higher)
        10MB hard disk space

        Recommended Configuration
        Pentium processor running at 166 MHz
        32MB RAM - 16MB free
        Sound card

        DirectX
        This game requires DirectX 7.0 or higher in order to run. If you do not 
        have this installed on your computer, you will need to obtain it before 
        you can run the game. You can obtain it from the Microsoft website at 
        http://www.microsoft.com/directx/download.asp.

       
      PLAYING THE GAME



        This game follows the straightforward rules of shoot-em-up's: Shoot at 
        anything that moves. If it doesn't move, shoot it anyway. Collect 
        anything that even resembles a bonus.
        Advance through waves of chicken invaders. Fire your primary laser at 
        chickens to destroy them, while simultaneously avoiding eggs dropping 
        down. When a chicken is destroyed, chicken legs fly out. Collect those 
        for missile bonuses. Hidden inside chickens and some asteroids are gift 
        boxes. Collect these to upgrade the power of your primary laser. 
        Keys:
              ESC  bypasses intro sequences
              F1  toggles detail level


              Left Player:
              A,D   move left & right
              Left Shift  fire
              Left Control  fire missile


              Right Player:
              Left, Right Arrows  move left & right
              Right Shift or Space  fire
              Right Control  fire missile

         
       
      TROUBLESHOOTING



        If the game complains that it is missing some DLL (usually ddraw.dll) at 
        start-up, then DirectX has not been properly installed (or at all). 
        Before reporting any problems, please go through the following list: 
          Re-boot your PC. 
          Do not load any other applications/games before launching the game 
          after booting up. 
          Do not switch to another application while the game is loading. 
          Do not switch to another application using Alt+Tab at any time. 
          Set your display color depth to High(16-bit) color (65000 colors) 
          before running the game. If it is already set for that color depth, 
          change it to something else (for example, 24-bit) and then back to 
          16-bit. You may have to re-boot after each color change. You can 
          change the color depth by right-clicking on your desktop, choosing 
          "Properties", choosing the "Settings" tab and changing the "Colors" 
          field. 
          (Re)install DirectX. 
        If everything else fails, note down: 
          Which game you are having problems with. 
          The processor type, graphics card type and operating system you are 
          running. 
          The version of the game you are running (found at the top of this 
          file). 
          At which point in the game the error occurs. 
          The precise error message you get. 
        ...and e-mail us.

        Changes:
              v1.01Recompiled for DirectX 7.0 to fix a DirectX vertical sync bug 
              on some systems.
              v1.00Internal release.

       
      CONTACT INFORMATION



        It's always a good idea to visit the InterAction software website for 
        latest news & information at http://ia.freeshell.org (you may need to 
        try a search engine if this address is no longer valid). You can also 
        e-mail any comments, suggestions etc. to 
        interaction.software@softhome.net .
         
       
      ACKNOWLEDGEMENTS



        "InterAction" and the iA logo are trademarks of InterAction software.
        "Pentium" is a trademark of Intel corporation.
        "DirectX" is a trademark of Microsoft corporation.
        "Dolby" and the Double-D symbol are trademarks of Dolby Laboratories 
        licensing corporation.
        All other brand and product names are trademarks or registered 
        trademarks of their respective holders.

       



      Copyright � 1999 InterAction software


