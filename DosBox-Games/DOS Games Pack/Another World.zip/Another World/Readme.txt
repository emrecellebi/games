

Manual Addendum
 
To leave the game type <Alt> X.  This will take you back to DOS.

To use the copy protection properly align the black arrow on the wheel
with the number you wish to address.

Thank You

