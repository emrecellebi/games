============================================

To see a demonstration game:

1 - Put all files into a single folder.
2 - Start DEMO.BAT

This is a complete game and provides a
rather quiet and unhurried trip through
much of the dungeon.  But there is a lot
more to see and do.

You can speed up the demonstration by
selecting 'QuickPlay' from the 'Misc' menu.

=============================================

To quickly start playing:

1 - Put all the files in a single folder.
2 - Run CSBwin.exe
3 - At the Menu, Click on 'Dungeon'
4 - At the Prison Door, Click on 'Resume'.
5 - At the Game Menu, Click on 'CSBGAME'.
6 - Select 'Play Game'
 
You will be in a dark room with three worms.
There are several torches in the room.  Two
are right beside you.  Pick one up and put it
in a hand of one of the heroes to light up
the room.  Then try to escape the room.  It 
will take some practice.  You can kick the
worms to death.  Or there is a dagger that
will help a little bit.  With two of the
coins on the floor you can buy a nice sword.
Some people prefer to run away from the worms
by putting a torch in the torch holder and
exiting the room through the opening that
will suddenly become available.  All of these
approaches will work.  Personal taste will
decide your fate.

============================================
There is a Config.txt file that allows most
of the game to be played without the mouse.
Using the keys makes the game much easier, IMHO.
You can edit the file to change the keyboard
mapping.  The standard file provides:

F1 - F4  Select Magic Caster
1 - 6    Magic Rune Selection
spacebar Cast Spell
k        Move forward
j        Turn Left
l        Turn Right
m        Move left
comma    Move backward
period   Move right

Use of weapons is controlled by the keys
QWERASDFZXCV.  Each action is initiated by
any one of several keys:

QAZ  Select First Hero for attack
WSX  Select Second Hero for attack
EDC  Select Third Hero for attack
RFV  Select Fourth Hero for attack
QWER Attack with first attack option
ASDF Attack with second attack option
ZXCV Attack with third attack option

For example, assume that the third hero
is carrying no weapon.  His options are
'Punch', 'Kick', and 'Warcry'.  By pressing
'D' you select him for the Attack and by
pressing 'D' again you casue him to 'Kick'.
Other combinations that would cause the same
thing are 'EF', 'CA', etc.  But 'DD' seems
the most natural.

Thanks to Christophe for suggesting these
particular mappings.  They only seem complicated
when I try to put them into words.  Using them
is easy.  I have found no reason to change them.

=============================================

To start the game from the beginning and to
select your own heros to play the game:

It is done by running the program three times.
First to select the party, second to create a
new game with that party, and third to begin
playing the game.  Sorry about the complication
but that is the way the Atari version did things.
It had to work with only 512K of memory and a
single floppy disk drive.  I copied it.

1 - Put all files in one folder.
2 - Run CSBwin.exe
3 - Click on menu 'Dungeon'
4 - At Prison door click on 'Prison'
5 - Wander about the prison and select a party.
6 - In the 'Inventory Screen' (you get to and from
    the inventory screen by right-clicking in the
    viewport area) select the Disk Menu (the little
    blue and white image of a disk in the upper
    right area) and select 'Save and Quit'.  Then
    select the name of the game you want to save.
7 - Quit the program.  Alt-F-X (or click on the close
    button in the extreme upper right corner of the 
    window) (or FileMenu option Exit).
8 - Run CSBwin.exe again.
9 - Select Utility.
10- Select the game that you saved in step 6.
11- Select 'Make New Adventure'
12- Select 'Make New Adventure' again on the 
    menu that says to put a disk in drive 'B'.
    You can safely ignore the Drive B message. ;-)
13- Select the name of the game you want to play.
    If a game by that name already exists you will
    be asked to verify that you wish to erase the
    old game.
14- Select 'Quit'.    
15- Run CSBwin again.
16- Select 'Dungeon'.
17- Select 'Resume'.
18- Select the game you saved in step 13.
19- Select 'Play Game'

You will be in that dark room with the three worms.
Good Luck!

=============================================
To get help with a particularly difficult
situation.

1 - Save your game using the disk menu on the
    inventory screen.
2 - Quit the program. Alt-F-X or other means.
3 - Run CSBwin again.
4 - Select 'Hint'
5 - Select 'Load'
6 - Select the name of the game you saved
    in step 1.
7 - Click on one of the options in the main
    window to get some hints.  You can get
    more explicit hints by clicking 'Next'.
8 - When done, quit the program, restart it,
    and resume your saved game.
    
When you are really stuck, you can ask for
help on the Chaos Strikes Back forum at
         --  dmweb.free.fr  --
The web site also has maps and additional hints.
In particular, it has the names of the spells.
If you have not played Dungeon Master then you 
will not know the spells.  At least one is 
absolutely necessary to win the game and others 
are extremely useful.

==========================================

Spells:  There are many spells.  Here are the
ones that I know without looking in the book.
Each is preceeded by a 'strength' which I
will indicate by 'x'.  For example, 'x4' produces
some light.  '14' produces a little light and
'64' produces a lot of light.

x4   Light
x345 Longer-lasting light
x44  Fireball
x2   Create Health potion
x1   Create Stamina potion
x25  Create Cure Poison potion
x6   Open door

============================================
The 'ASCIIDUMP' option after selecting a game
to play will produce a more-or-less human-readable
file named 'ASCIIDUMP.TXT' which will detail
every pressure pad, switch, object, etc. that 
the dungeon contains.  It is my 'Bible' of the
dungeon when I want to know how and why things
are happening as I play the game.

==============================================

Be sure to let me know if you find bugs in the 
program.  prsteven@facstaff.wisc.edu

If you enjoy the game it would be very nice
to receive a note from you.  I created this
program for my own benefit but it feels really
good to find that others enjoy it.

If you ask for enhancements to the program you
are likely to be politely told 'No'.  I want the
game to be faithful to the original.  But the
symbolics are available!  You can program the
enhancements yourself.