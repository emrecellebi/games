Copy protection bypass:

The first time you play, you will be prompted to look up a word in the manual after the first round of stock purchasing is complete. Simply press ENTER to bypass all of the protection verification prompts. 

The manual claims: (after verification)... you will never need to worry about copy protection again unless you copy the program to another machine or reinstall it.

After initial testing, this seemed to be the case.