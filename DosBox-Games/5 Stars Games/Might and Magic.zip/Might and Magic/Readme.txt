Might and Magic - Secret of the Inner Sanctum
Copyright 1986-1997 The 3DO Company.
All Rights Reserved.

New World Computing is a division of The 3DO Company.

Might and Magic, the Might and Magic logo, New World Computing, 
the New World Computing Logo, The 3DO Company, and it's logo's
are trademarks and or registered trademarks of The 3DO Company.
All other trademarks belong to their respective holders.
---------------------------------------------------------------

A Note From the Creator
-----------------------
As designer of the Might and Magic series, I would
like to personally thank you for your interest in
Might and Magic - Secret of the Inner Sanctum.

The Might and Magic saga will officially continue
using state of the art technologies at the end of
1997.

Again, thank you for your continued support.

Jon Van Caneghem
President
New World Computing.
-------------------------------------------------------------

To view the manual, you need to run Adobe Acrobat Reader.

Adobe Acrobat Reader
--------------------
We recommend using the Windows version of the Acrobat Reader.
Windows 95
   1.  Open the Windows Explorer.
   2.  Click on the CD-ROM (i.e. D:)
   3.  Double click on the Acroread Folder in \demos\mm1\acroread.
   4.  Double click on Acroread (AcroW95.EXE).
   5.  Read and accept the agreement.
   6.  Check your disk space and select destination directory for
       Acrobat files.
   7.  Enter your name and your Organization's name (if applicable).
   8.  Double click on the Acrobat Reader 3.0 icon to begin.
Windows 3.1
   1.  Open the File menu and select Run.
   2.  Enter D:\DEMOS\MM1\ACROREAD\ACROW31.EXE
       NOTE: D: represents your CD-ROM Drive. 
             Substitute another letter as necessary.
   3.  Follow steps 5 through 8 in the Windows 95 installation above.
MS-DOS
   1.   Go to your CD-ROM drive (i.e. D:).
   2.   Change directory to ACRODOS (cd \demos\mm1\acroread\acrodos).
   3.   Type INSTALL.
   4.   Read and accept the agreement.
   5.   Enter your name and your organization's name (if applicable).
   6.   Select destination drive and directory for Acrobat files.
   7.   Select destination directory for Post-script fonts.
   8.   Choose whether or not you want to install the tour.
   9.   Select video driver (default 8514).
   10.  Select destination for the temporary directory.
   11.  Select destination for the swapfile directory.
   12.  Choose whether or not to edit the CONFIG.SYS and AUTOEXEC.BAT
        files.
   13.  Reboot your computer.
   14.  Change directory to ACRODOS and type ACROBAT to begin.  Type
        ACROBAT from the C: prompt, if you edited the AUTOEXEC.BAT.

Using Adobe Acrobat Reader to View the Manuals
   1.  Enter Acrobat Reader, the program will open with the Open
       File Menu.
   2.  Change the drive to your CD-ROM drive (make sure the CD is in 
       the drive).
   3.  Select the Manual.PDF file. (\demos\mm1\manual\manual.pdf).
   4.  Use the scrollbar on the right of the screen, or the arrow
       buttons on the toolbar in the top-center of the screen to
       change pages.
   5.  To print, open the File menu and select Print.


Reaching the 3DO Company
----------------------------
       The 3DO Company
       600 Galveston Drive
       Redwood City, CA 94063
       (415) 261-3000 
       www.3do.com

       Contact 3DO Customer Service at (415) 261-3454 or
       customer-support@3do.com

