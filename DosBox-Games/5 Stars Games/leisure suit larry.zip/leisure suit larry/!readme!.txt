T�to hru m�te z web str�nky ->>> WWW.BESTOLDGAMES.NET <<<- �akujem za n�v�tevu;)
This game is downloaded from website ->>> WWW.BESTOLDGAMES.NET <<<- Thank you for your visit;)

V pr�pade, �e si neviete rady so spusten�m star�ch hier na nov�ch po��ta�och, nav�t�vte str�nku: 
				http://www.bestoldgames.net/dosbox.php


##     ## ##     ## ##     ##
##     ## ##     ## ##     ##
 ## # ##   ## # ##   ## # ##
  #####     #####     #####
   # #       # #       # #  o


####   #####  ####  ########  ######  ##     ####      #####     ##    ##   ##  #####   ####
##  #  ##    ##        ##     ##  ##  ##     ##  ##   ##        ####   ### ###  ##     ##
####   ###     ##      ##     ##  ##  ##     ##   ##  ##  ##   ##  ##  ## # ##  ###      ##
##  #  ##        ##    ##     ##  ##  ##     ##  ##   ##   ##  ######  ##   ##  ##         ##
#####  #####  ####     ##     ######  ###### #####     #####   ##  ##  ##   ##  #####   ####  o


                                                                       ##   ##  #####  ########
                                                                       ###  ##  ##        ##
                                                                       ## # ##  ###       ##
                                                                       ##  ###  ##        ##
                                                                       ##   ##  #####     ##


                                                                                  -mylan-
                                                                           mylan@bestoldgames.net
