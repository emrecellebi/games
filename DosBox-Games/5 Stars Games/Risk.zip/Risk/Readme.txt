



RISK V1.9

This disk contains keyboard driver V5.1 to emulate certain features of
a Microsoft compatible mouse.
Use the cursor keys (2,4,6 & 8) on the keypad to move the pointer.
Key 5 on the keypad emulates the left mouse button.
The Num Lock key emulates the right mouse button.
Keys F1 to F10 set the speed of movement (F1=fine, F10=coarse).
Home,Pgup,End and Pgdn on the keypad move the pointer to the 4 quadrants
of the screen.

This disk contains joystick driver V3.0 to emulate certain features of
a Microsoft compatible mouse.
The primary joystick button emulates the left mouse button.
The secondary joystick button emulates the right mouse button.
If you do not get full screen coverage (or too much coverage), vary
the position of the stick when you are asked to center it.

We welcome any comments you may have about this product...

Write to:
Virgin Mastertronic, Inc.
18001 Cowan Street
Suites A and B
Irvine, California 92714
Attention: Customer Service

Ph. (714) 833-8710
Fax (714) 833-8717
