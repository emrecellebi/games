Thank you for downloading Transport Tycoon Deluxe from Transport Tycoon.co.uk

To install run Setup.exe and install TTD. 

For Windows 95, 98 and ME just start the game normally when its installed. 

But, for Windows NT 4, 2000 and XP you will need to install the patch. 
Look in the folder: "Patch for NT, 2k and XP"


Matt Gillard	
http://www.mattgillard.co.uk