DarkSoul04 modified Readme:

First install the game normally. Go to X:\MPS\TTWin95 (Where X is you drive letter) 
or where ever you installed TTD and put the ttdpatchw.exe file in there. RUN it!
The patch file will make a few more files and then should start the game. 

If the game doesn't start find the error in the list and look at the solution.

Error Reading Registry
Go to Start, Run and Type regedt32 (Not regedit). Find
HKEY_LOCAL_MACHINE\SOFTWARE\FISH Technology Group\Transport Tycoon Deluxe\HDPath and double click it. Then simply click OK. Don't make any changes. Try again

Create process failed
Delete the file TTDLOADW.OVL and run TTDPatch again.

Not Full screen or no sound
First try the TTconfig.exe and select a different sound mode for sound problems (soundblaser) or display mode for display problems (display mode 4 or 5).
Try setting ttdpatchw.exe (and/or TTD itself) to run in Windows 95 or Windows 98 compatibility mode. Simply right click on the file and Compatibility tab.


