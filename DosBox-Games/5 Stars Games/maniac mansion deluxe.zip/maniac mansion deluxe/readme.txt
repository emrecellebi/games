Maniac Mansion Deluxe

The team behind The New Adventures of Zak McKracken has released Maniac Mansion Deluxe, the 256-colour remake of LucasArts classic adventure. "With its improved SCUMM-interface, digital sound effects and continuous background music it�s the best Maniac Mansion ever made!" 
 
There are weird people living in Maniac Mansion: Dr. Fred, a "retired" physician turned mad scientist; Nurse Edna, a former health care professional whose hobbies would make a sailor blush; Weird Ed, a teenage commando with a hamster fetish; and then there's Dead Cousin Ted, and the Tentacle, and somebody - or something - else... And what's a sweet young cheerleader named Sandy doing in Dr. Fred's basement?

Min. REquirements:
Pentium 233, 32 MB, Windows 95/98/2000/XP