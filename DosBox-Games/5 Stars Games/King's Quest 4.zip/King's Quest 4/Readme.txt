King's Quest IV AGI: The Perils Of Rosella

This a rare AGI version of King's Quest IV. It's
the same game as the other but has an AGI interface.

Note: At the copy protection screen in the beginning
of the game, press Alt + D.
When you get to the empty prompt either type in "marble"
to play the game or for a surprise type "pirate".

