Betrayal at Krondor 
Version 1.02 (CD) Release Notes

CD NOTES
The CD version of Betrayal at Krondor can be installed in two ways:
A partial install which takes up 2.6 megabytes of hard drive space or
the full install which requires 15 megabytes. While running under the 
partial install, the new CD music will not be heard and the game will 
run slower as information is being read off the CD. 

VERSION 1.02 NOTES
-In this version players can toggle between a "fixed" and a "rotating"
 overhead map display by pressing the "n" key while viewing the 
 overhead view. 
-Extra rope has been added to Chapter Five.
-More supplies have been added to the beginning of Chapter Nine.
-Another clue has been added in Chapter Three.
-Armorcraft and weapons skills increase faster than version 1.0 or 1.01.
-Items placed in moredhel lock chests can no longer be "stolen." It was
 possible to steal items out of the moredhel chests and then not have 
 important items later in the game.

GENERAL NOTES
Betrayal at Krondor is a complex game with many intricate subplots. 
When you encounter an important character, or come across an important 
piece of information, you may want to take a few notes. You may also find 
it useful to go back and visit important characters or places more than 
once, as you might receive new information.

Some actions could require multiple attempts. For example, you can 
retreat from MOST combat situations, but your odds of success on any 
given turn are less than 50%. Don't be discouraged if your first try 
fails, subsequent attempts could provide different results.

To improve performance on some systems, it helps to load a disk caching 
utility like Microsoft's SMARTDRV.EXE program. Disk caching utilities 
reduce the number of times a program has to access the hard drive, 
speeding up certain program operations. If you are using a boot disk to 
run Betrayal at Krondor, you may want to add a line to the boot disk 
CONFIG.SYS or AUTOEXEC.BAT file that loads such a utility. For full 
instructions on loading the disk caching utility of your choice onto your 
boot disk, please refer to the manufacturer's documentation.  

The BOOKMARK option is an excellent way to save your game, but it should 
not be used exclusively, as you will have no backups. (If you accidently 
use this option during a particularly tough point in the game, it is nice 
to have some other games to restore to.)

If you have more than 1 Mg of free Expanded Memory, Krondor will use this  
extra memory, thus allowing your game to run faster and smoother. Also, 
if you are playing the game with less than 595,000 bytes of conventional 
memory, some sounds may not be played. This will not affect gameplay. You 
can free up enough memory to play the sounds by creating a boot disk. 
Re-run the install program from the Krondor directory on your hard drive 
and select the "Make Bootable Floppy" option.

Do not allow ALL your characters to become incapacitated or "frozen" 
during combat. Even though they are not "down," if none of your 
characters can move, the enemy will sweep in and kill them, thus ending 
the game. 


STACKER
We have found that Betrayal of Krondor works best with Stacker if you 
remove the /EMS or /UM switch from your CONFIG.SYS file (on your boot 
disk only). You will want to remove these switches so your computer will 
not cache to Expanded Memory, or to Upper Memory. (Consult your DOS or 
Stacker manual for more information on editing this file.)


DOS 6.0 AND DOUBLESPACE
For DOS 6.0 and Doublspace users, you may want to redirect Krondor's 
TEMP.GAM file to your UNCOMPRESSED drive. To do this, go to the Krondor 
directory and load the "RESOURCE.CFG" file using a text editor or word 
processor. Then add the following line:  TEMPDRIVE = H:\  (Note: If 
your uncompressed drive uses a different drive designation, replace the 
"H" in the line above with the correct drive letter.)

                          
                     MANUAL INSTALL INSTRUCTIONS 
Sierra On-Line's Technical Support department prepared the following
instructions as an added service to our customers. PLEASE NOTE: NEITHER
SIERRA NOR DYNAMIX MAKE ANY CLAIMS, GUARANTEES, AND/OR PROMISES THAT THE
FOLLOWING INSTRUCTIONS WILL WORK ON ANY AND/OR ALL COMPUTER SYSTEMS.

If you are experiencing problems with the Betrayal at Krondor INSTALL 
program, the following instructions will allow you to manually copy the 
game to your hard disk drive.

NOTE: The following instructions should be used only as a last resort.
Try using a Betrayal at Krondor Boot Disk first. Start the INSTALL 
utility and choose the "Make bootable floppy disk" option. After 
creating the Boot Disk, reboot your computer and run the Betrayal at 
Krondor install program. If the install program continues to fail then 
use these directions to manually copy the program to your computer's 
hard disk drive.

1) Check your hard disk drive to confirm that you have at least 15 Megs 
   of disk space available. IMPORTANT NOTE: If you are installing 
   Betrayal at Krondor to a drive using disk compression (i.e. 
   DoubleSpace, Stacker, SuperStor...) you will need at least 30 Megs 
   free prior to installation. Run the "CHKDSK" utility to verify "bytes 
   available on disk".

2) Create a DYNAMIX directory, and then a KRONDOR subdirectory under
   Dynamix. Copy all the files from each disk into the \DYNAMIX\KRONDOR
   subdirectory.

3) Go to the \DYNAMIX\KRONDOR directory on your hard drive.

IMPORTANT: Make sure to include the space period at the end of the next
command.

[NOTE FOR CD USERS: Steps 5-6 are not nessacary if installing from a
 CD.  Simply copy all the files from the root directory of the CD into
 the directory created in the steps above.  Next you will need to create
 a file that indicates the drive letter of the hard drive and the CD.
 Using a text editor (like DOSs 'EDIT' command) create a file called
 DRIVE.CFG in the same directory as the Betrayal At Krondor files.  The
 first line of the file should contain the letter of the hard drive and
 the second line should contain the letter of the CD drive.  A typical
 example would be C (followed by [ENTER]) for the hard drive letter and
 D for the CD drive. Once you have created the DRIVE.CFG file proceed to
 step 7.]

4) Now type: UNCHUNK RESOURCE.000  .

5) As soon as the RESOURCE file has finished decompressing, delete that
   RESOURCE by typing:

   DEL RESOURCE.000

6) Repeat steps 4 and 5 again on RESOURCE.001, through RESOURCE.006 by
   substituting the appropriate resource number extension in the unchunk
   and del statements in steps 4 and 5.

NOTE: Be sure to unchunk these resource files in order. If you make a
mistake, or if the unchunked files are in the wrong order, you will need 
to erase all of the files from the \DYNAMIX\KRONDOR directory and all
subdirectories, then follow steps 2 through 5 again.

7) After all resource files have been "unchunked", run the install 
   program from the \DYNAMIX\KRONDOR subdirectory by typing INSTALL at 
   the KRONDOR prompt. Check to confirm that the sound and music 
   settings are correct. Choose "ACCEPT THESE CHOICES" from the options 
   in the program. Follow all the other prompts as they appear.

8) Exit out of the Install program and try running the Krondor program by
   typing KRONDOR.

If you continue to experience any problems, or if you have any questions
concerning any of the above steps, our technical support team will be 
more than happy to assist you. Please call (209) 683-8989 between 8:15 
AM and 4:45 PM Monday through Friday. We can also be reached by fax at 
(209) 683-3633, by BBS at (209) 683-4463, or by mail at the following 
address:

                              SIERRA ON-LINE
                               P.O. BOX 800
                        COARSEGOLD, CA  93614-0800
                         ATTN:  TECHNICAL SUPPORT

In Europe, please contact our office in Berkshire, England. The Customer
Service phone number is [44] 734 303171, the Hint number is [44] 734-
304004, the BBS number is [44] 734-304227, the Fax number is [44] 734
303201, and the address is:

                          SIERRA ON-LINE LIMITED
                     UNIT 2, THEALE TECHNOLOGY CENTRE
                               STATION ROAD
                                  THEALE
                            BERKSHIRE, ENGLAND
                                  RG7 4AA

Please outline the problems along with specific information about your
computer system, and we will gladly respond to your fax or letter as soon
as possible.
