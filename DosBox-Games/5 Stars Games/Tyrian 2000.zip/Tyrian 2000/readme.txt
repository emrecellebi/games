TYRIAN 2000 [TM]

Version 1.0
Release Notes

October 5, 1999

Please read the following information. It contains last minute release
information.

=========================================================================

1. The game does not support two joysticks at one time for two player mode.
   You cannot use the patch through abilities of something like the Wingman
   or Sidewinders, nor can you use a splitter.  The game cannot make use of
   both controllers in two player mode.  It can only use combos of two of the
   following: the mouse, one controller, or the keyboard.

2. The game does not support the "GrIP" feature on the Gravis Gamepad Pro. If
   the GrIP switch is set to "GrIP" on the back of the Gravis Gamepad Pro, Tyrian
   2000 will not function.  You will see the main menu appear for a second before
   being booted back to Windows.  The GrIP switch must be turned to the "One
   Player" selection on the back of the gamepad or else Tyrian 2000 will not work
   with a Gravis Gamepad Pro.

3. Even though Tyrian 2000 can be run under DOS, we strongly recommend that you
   run the game from Windows."

4. This is a mixed mode CD. This means that it is split into an audio CD and a data
   CD. Some audio CD players cannot play audio CD music from a mixed mode CD. The
   audio CD music should be playable from all Windows 95/98 computers.

===========================================================================

If you experience any problems, send an email to <support@xsivgames.com>

or

visit the support area of our web site at WWW.XSIVGAMES.COM

or

call Stealth Productions toll free at 1-877-4STEALTH (1-877-478-3258)

===========================================================================

Tyrian 2000 Game Copyright (c) 1999, Eclipse Software
Tryian 2000 Copyright (c) 1999, Stealth Productions, Inc.
All Rights Reserved.
