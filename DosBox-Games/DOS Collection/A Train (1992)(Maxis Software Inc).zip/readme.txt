Welcome to the A-Train README file.

This file will tell you how to update A-Train for compatibility with 
MS-DOS 6.0.

There are two files here that you need: AT.EXE and AT.OVL.  Merely
copy them into your A-Train directory.  They will overwrite your 
current files of the same names.

One important thing: If you have A-Train Version 1.0, you need to 
upgrade that version before you put these files into your A-Train 
directory.  You can find out your version of A-Train by either 
re-running the A-Train INSTALL program, or by pressing CTRL-ALT-V 
while in the game.  (You will know if you have the 1.0 version if you 
run the install and the text says "Version 1.0 (beta)."  This is a typo 
made after far too much testing way too late in the evening, and us 
running out of coffee.)

A newer version of A-Train can be obtained by calling 1-800-33-MAXIS.
The awesome people in Customer Service will be happy to send off an 
update.

Confused?  Me too.  Here's the instructions one more time (in English).
1.  Make sure you have the newest version of A-Train (V1.02).
2.  Copy the AT.EXE and AT.OVL into the A-Train directory.
3.  Run A-Train. :)

For the Construction Set, the new INSTALL.EXE file is here also.  You need 
to copy the INSTALL.EXE file to your Construction Set install disks, then
rerun the install program.  (We recommend copying this file to your backup
disks.  You did make backups, right?)

Instructions for that, one more time.
1. Copy the INSTALL.EXE file onto your A-Train Construction Set
   install disks (please do this to your backups).
2. Run the A-Train Construction Set install program. 

Brought to you by the decompressed members of the Jimbo's Peanut S.I.G.
and the Maxis Motorcycle Road Warriors.
-Peter





