

  If you have trouble with abuse call our technical support line
at 1 303 339 7158.  Please do not call with problems other than
with the real game (not the edit or lisp programming).  You can also
consult with http://www.crack.com or email help@crack.com (prefered).

  This line does not supported shareware copies.




