

README.TXT

von Sean Mustakas


Inhalt
------

1. Systemanforderungen

2. Installation

3. Empfohlene Konfigurationen/Startdiskette

4. Soundkarten-Einstellung

5. Kundendienst


1. Systemanforderungen
--------------------

Um ABUSE zu spielen, ben�tigen Sie mindestens folgendes System: 

Intel 486/DX2-50 oder 100% kompatible
MS DOS 5.0 (oder h�her) oder Windows 95
8 MB RAM
400K freien konventionellen Speicher
13 MB freier Festplattenspeicher
256-Farben VGA-Videokarte mit 1 MB V-RAM 
MS Mouse oder 100% kompatible (mit MS oder 100% kompatiblem Treiber)
CD-ROM-Laufwerk (nur zur Installation auf die Festplatte)

Netzwerk-Spiel (2-8 Spieler):

Intel 486/DX2-66 oder 100% kompatible
Windows 95
IPX-kompatibles Netzwerk / Treiber

Sound (optional): 

Sound Blaster oder 100% kompatible Soundkarte f�r Digital SFX
Roland MPU-401 General MIDI oder 100% kompatible Soundkarte f�r MIDI Musik


2. Installation
---------------

So installieren Sie ABUSE:



DOS:

1. Legen Sie die CD in Ihr CD-ROM-Laufwerk.
2. Wechseln Sie zum CD-ROM-Laufwerk (tippen Sie "D:" oder "E:").
3. Tippen Sie "Install".
4. Folgen Sie den Bildschirmanweisungen.

So starten Sie ABUSE unter DOS:

1. Wechseln Sie zum ABUSE-Verzeichnis.
2. Tippen Sie "ABUSE".

Beispiel:

C:
CD ABUSE
ABUSE



Windows 95:

1. Legen Sie die CD in Ihr CD-ROM-Laufwerk.
2. Doppelklicken Sie auf das Symbol "Arbeitsplatz".
3. Doppelklicken Sie auf den CD-ROM-Laufwerkbuchstaben (meist "D" oder "E").
4. Doppelklicken Sie auf "INSTALL.EXE".
5. Folgen Sie den Bildschirmanweisungen (verwenden Sie die Tastatur
   in der DOS Box).
6. Wechseln Sie zum Fenster "Arbeitsplatz" zur�ck und doppelklicken Sie auf
   den Buchstaben des Laufwerks, auf dem Sie ABUSE installiert haben
   (Standardvorgabe ist "C").
7. Doppelklicken Sie auf den ABUSE-Ordner.
8. Doppelklicken Sie auf "ABUSE.EXE", um das Spiel zu starten.


Hinweise:

Wenn Sie eine Liste der Tastatur- und Mausbefehle sehen wollen,
k�nnen Sie jederzeit w�hrend des Spiels "F1" dr�cken.

Sie k�nnen w�hrend der Installation ein anderes Installationsverzeichnis
w�hlen. Das Installationsprogramm wird dann das neue Verzeichnis f�r
Sie erstellen.

ABUSE kann NUR von der Festplatte aus gespielt werden. Die CD
dient lediglich der Installation!

Sie k�nnen ABUSE schneller starten, wenn Sie unter Windows 95
auf dem Desktop eine Verkn�pfung zu ABUSE.EXE erstellen.


3. Empfohlene Konfigurationen/Startdiskette
-------------------------------------------


F�r eine Maschine mit 8 MB (oder mehr):

"CONFIG.SYS"

DEVICE=C:\DOS\HIMEM.SYS
DOS=HIGH
(F�gen Sie hier Ihren CD-ROM-Treiber ein,
z.B. "DEVICE=C:\SCSI\ASPICD.SYS /D:ASPICD0")
FILES=40
BUFFERS=40
SHEll=C:\DOS\COMMAND.COM C:\DOS /P

"AUTOEXEC.BAT"

PATH=C:\DOS;C:\
PROMPT $P$G
(F�gen Sie hier Ihren MSCDEX.EXE-Treiber ein,
z.B. "C:\DOS\MSCDEX.EXE /D:ASPICD0 /M:12 /L:E")
C:\DOS\SMARTDRV.EXE 2048 (F�gen Sie dies nach der Installation ein,
um die Geschwindigkeit zu steigern!)
(F�gen Sie hier Ihren Maustreiber ein, z.B. "C:\MOUSE\MOUSE.EXE")
SET COMSPEC=C:\DOS\COMMAND.COM
C:


HINWEIS:
Falls Sie nicht �ber genug konventionellen Speicher verf�gen, um das
Spiel zu starten, versuchen Sie, EMM386.EXE (den Speicher-
Verwaltungsmanager von DOS) zu laden: F�gen Sie Ihren Zeilen die 
Befehle DEVICEHIGH und LH hinzu, um soviel Speicher wie nur 
m�glich freizumachen. F�gen Sie der Zeile "DOS=HIGH" den Befehl 
"UMB" hinzu (DOS=HIGH,UMB).

Beispiel:

"CONFIG.SYS"

DEVICE=C:\DOS\HIMEM.SYS
DEVICE=C:\DOS\EMM386.EXE NOEMS
DOS=HIGH,UMB
(F�gen Sie hier Ihren CD-ROM-Treiber ein,
z.B. "DEVICEHIGH=C:\SCSI\ASPICD.SYS /D:ASPICD0")
FILES=40
BUFFERS=40
SHEll=C:\DOS\COMMAND.COM C:\DOS /P

"AUTOEXEC.BAT"

PATH=C:\DOS;C:\
PROMPT $P$G
(F�gen Sie hier Ihren MSCDEX.EXE-Treiber ein,
z.B. "LH C:\DOS\MSCDEX.EXE /D:ASPICD0 /M:12 /L:E")
(F�gen Sie hier Ihren Maustreiber ein, z.B. "LH C:\MOUSE\MOUSE.EXE")
SET COMSPEC=C:\DOS\COMMAND.COM
C:


Weitere Hinweise:

Nach einer erfolgreichen Installation k�nnen Sie auch die CD-ROM-Treiber aus
Ihrer Konfiguration entfernen. Dies sollten Sie aber nur dann tun,
wenn weiterhin ein Speicherproblem existiert.

Falls Sie ein SCSI-CD-ROM-Laufwerk besitzen, sollten Sie auch den
SCSI-Adapter-Treiber vor der CD-ROM-Treiberzeile eingeben
(CD-ROMs, die von der Soundkarte abh�ngen sollten den Soundkarten-Treiber
vor der CD-ROM-Zeile laden).

Beispiel:
    "DEVICE=C:\SCSI\ASPI8DOS.SYS /D /p234"
    "DEVICE=C:\SCSI\ASPICD.SYS /D:ASPICD0"

Manche Soundkarten erfordern, da� Sie Treiber laden, damit die Karten
funktionieren. F�gen Sie diese Treiber hinzu, so wie sie in Ihrer
normalen Konfiguration erscheinen. Der einfachste Weg hierzu ist die
Erstellung einer Startdiskette mit der unten angegebenen
Konfiguration. L�schen Sie keine Zeile, die etwas mit Sound zu
tun hat.

Falls Sie in Ihrer AUTOEXEC.BAT keinen Maustreiber finden, so suchen
Sie in Ihrer CONFIG.SYS nach einer Zeile, die das Wort "MOUSE.SYS"
enth�lt. Diese funktioniert ebenfalls und kann auf die gleiche Art
geladen werden:

Beispiel:
    "DEVICE=C:\DOS\MOUSE.SYS"

Die Verwendung des Cache-Programms SMARTDRV.EXE kann die
Spielgeschwindigkeit deutlich verbessern, aber es gibt dabei manchmal
Probleme mit dem Installationsproze�. Wir empfehlen, das Spiel
erst ohne SMARTDRV zu installieren und den Cache erst zu aktivieren,
nachdem Sie sich vergewissert haben, da� die Installation erfolgreich
war (d.h. starten Sie erst einmal das Spiel!).

Da ABUSE einen DOS-Extender zur Speicherverwaltung verwendet,
m��te es unter einer Reihe von Konfigurationen laufen. Falls Ihre
Konfiguration zu Problemen f�hrt, empfehlen wir die Erstellung
einer Startdiskette. Um sicher zu gehen, sollten Sie eine
Startdiskette erstellen, BEVOR Sie das Spiel installieren, um eine
passende Konfiguration zu gew�hrleisten (im allgemeinen ist
es unter Windows 95 nicht n�tig, eine Startdiskette zu erstellen).

Erstellung einer Startdiskette:

1. Legen Sie eine leere Diskette in Ihr Laufwerk "A".

2. Tippen Sie an der C:\-Eingabeaufforderung "FORMAT A:/S".
   (Sie k�nnen auch "SYS A:" verwenden, wenn die Diskette
   vorformatiert ist.)

3. Nach Abschlu� der Formatierung tippen Sie "COPY C:\CONFIG.SYS A:"

4. Tippen Sie "COPY C:\AUTOEXEC.BAT A:"

5. Tippen Sie "EDIT A:\CONFIG.SYS" und modifizieren Sie dann Ihre
   Datei, um sie an die oben angegebenen Konfigurationen anzupassen.
   Tippen Sie "REM" am Beginn jeder Zeile, die Ihnen unn�tig erscheint,
   z.B. "REM C:\WINDOWS\IFSHLP.SYS".

6. Speichern Sie die modifizierte Datei, indem Sie den Befehl
   "SPEICHERN" und anschlie�end "BEENDEN" aus dem Datei-Men� w�hlen.
   Sie k�nnen diese Befehle mit der Maus aktivieren, falls vorhanden.

7. Tippen Sie "EDIT A:\AUTOEXEC.BAT" und �ndern Sie diese Datei
   in der gleichen Weise wie vorher die CONFIG.SYS. 

8. Speichern Sie die Datei AUTOEXEC.BAT und w�hlen Sie "Datei beenden".

9. Starten Sie Ihren Computer erneut und beginnen Sie mit ABUSE!

HINWEISE -

Wenn Sie m�chten, da� Ihre Startdiskette ABUSE automatisch beginnt, dann
f�gen Sie diese Zeilen am Ende Ihrer AUTOEXEC.BAT ein:

C:
CD ABUSE
ABUSE

Nat�rlich m�ssen Sie diese Zeilen entsprechend modifizieren, falls Sie
w�hrend der Installation ein anderes Laufwerk und/oder Verzeichnis
gew�hlt haben.


4. Soundkarten-Einstellung 
--------------------------

Wenn Sie das erste Mal ABUSE.EXE starten, m��te das
Sound-Einstellungsprogramm SETUP.EXE automatisch laufen.
Falls Sie Ihre Einstellungen �ndern wollen, oder der Bildschirm
des Einstellungsprogramms nicht erscheint, k�nnen Sie den Proze� manuell
starten, indem Sie einfach im ABUSE-Verzeichnis "SETUP" tippen. Sobald
Sie sich auf dem SETUP-Bildschirm befinden, k�nnen Sie die Pfeiltasten
verwenden, um Optionen zu wechseln, und die Eingabetaste, um sie
auszuw�hlen. Es gibt Optionen f�r DIGITALE und MIDI-Karten. Allerdings
k�nnen nur digitale Karten vom Autodetect-Programm erkannt werden.
Falls Sie sich nicht absolut sicher sind, welche Einstellungen Ihre
Soundkarte hat, ist AUTODETECT unbedingt zu empfehlen. Falls
AUTODETECT nicht funktionieren sollte, starten Sie dieses Programm
einfach erneut (dann wird eine andere Methode verwendet). Sollte
Ihr System w�hrend dieses Prozesses einfrieren, so f�hren Sie
einfach einen Neustart Ihres Computers durch und versuchen Sie es nochmals.
Es ist zu empfehlen, die TEST-Funktion zu benutzen, um sicherzugehen,
da� auch alles funktioniert. Sobald Ihre Karte korrekt eingestellt
ist, w�hlen Sie "OK", um diese Konfiguration zu speichern.
Sie k�nnen auch jederzeit "ABBRECHEN" w�hlen, um das SETUP-Programm
zu verlassen, ohne die derzeitige Konfiguration zu speichern.

HINWEISE:

Sie ben�tigen eine MPU-401 General MIDI-Soundkarte, um im Spiel Musik zu
h�ren - eine Sound Blaster alleine kann nur digitale Soundeffekte
erzeugen (mit Ausnahme der SB/AWE32, die sowohl als digitale Quelle als
auch als Musik-Quelle funktioniert). MPU-401 kompatible Tochterkarten d�rften
auch f�hig sein, Musik abzuspielen.

Versuchen Sie nicht, die AUTODETECT-Funktion laufen zu lassen, wenn Sie
keine Soundkarte besitzen!


5. Kundendienst
---------------


Wenn Sie Probleme mit ABUSE haben, so k�nnen Sie unseren Kundendienst
anrufen (die technische Beratung ist kostenlos, aber es fallen
nat�rlich Geb�hren f�r das Ferngespr�ch an) oder uns auf eine
andere Weise kontaktieren. Bitte halten Sie folgende
Informationen bereit:



1. Eine EXAKTE Kopie des Inhalts Ihrer CONFIG.SYS und AUTOEXEC.BAT,
   unter denen Sie unser Produkt installieren bzw. spielen.
2. Den Hersteller und Typ Ihres Computers.
3. Den Hersteller und die Version des von Ihnen benutzen DOS.
4. Den Hersteller und Typ Ihrer Videokarte (und gegebenenfalls die
   Treiber-Version).
5. Den Hersteller und Typ Ihrer Soundkarte(n).
6. Den Hersteller und Typ Ihres CD-ROM-Laufwerks (und Treiber-Version).
7. Eine Liste der aufgetretenen Fehlermeldungen.
8. Eine Liste anderer Hardware in Ihrem System (Einstellungswerte
   w�ren auch sehr n�tzlich!).
9. Gegebenenfalls eine Liste Ihrer Netzwerktreiber und Hardware.


Kundendienst:

EA-Kundendienst        - (05241) 26024 (M-F, 9-12h und 13-17h)
FAX                    - (05241) 24244
Origin-Mailbox         - 001-512-346-2227 (Anfragen bitte nur auf Englisch)
Internet FTP           - support@origin.ea.com (Anfragen bitte nur auf Englisch)

