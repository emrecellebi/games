

README.TXT

par Sean Mustakas


Table des mati�res
---------

1. Configuration n�cessaire 

2. Installation

3. Configurations sugg�r�es/Infos sur la disquette de d�marrage

4. Installation de la carte son

5. Support technique/Aide 


1. Configuration n�cessaire du syst�me
---------------------

Afin de jouer �  ABUSE, vous devez avoir au moins : 

Processeur Intel 486/DX2-50 ou un syst�me 100 % compatible
Version MS DOS 5.0 (ou ult�rieure) ou Windows 95
8 Mo de m�moire RAM
400 Ko de m�moire conventionnelle disponible
13 Mo d'espace disque dur disponible
Carte vid�o VGA � 256 couleurs avec 1 Mo de m�moire RAM vid�o
Souris Microsoft ou 100 % compatible (avec gestionnaire Microsoft ou 100 % compatible)
Lecteur CD-ROM (pour installation sur le disque dur seulement)

Jeu sur le r�seau (2 � 8 joueurs) :

Processeur Intel 486/DX2-66  ou 100 % compatible
Windows 95
R�seau compatible IPX homog�ne avec gestionnaires

Son (facultatif) : 

Carte Soundblaster ou carte son 100 % compatible pour effets sonores num�ris�s
Carte son Roland MPU-401 General MIDI ou carte son  100 % compatible pour musique MIDI


2. Installation
--------------

Pour installer ABUSE -

DOS :

1. Ins�rez le CD dans votre lecteur CD-ROM.
2. Tapez la lettre correspondant au lecteur sur lequel se trouve le 
CD. (g�n�ralement "D:" ou "E:")
3. Tapez "Install"
4. Suivez les instructions affich�es sur l'�cran

Pour commencer � jouer � ABUSE -

1. Allez sur le r�pertoire d'ABUSE.
2. Tapez "ABUSE"

Exemple :

C:
CD ABUSE
ABUSE

Windows 95 :

1. Ins�rez le CD dans votre lecteur CD-ROM.
2. Double-cliquez sur l'ic�ne "Poste de travail".
3. Double-cliquez sur la lettre correspondant au lecteur de votre
 CD-ROM (g�n�ralement "D" ou "E")
4. Double-cliquez sur "INSTALL.EXE".
5. Suivez les instructions sur l'�cran .(Must Use Keyboard in DOS Box)
6. Retournez � la fen�tre "My Computer"et double-cliquez sur la lettre 
correspondant au lecteur sur lequel est install�  ABUSE ("C" par d�faut)
7. Double-cliquez sur le dossier ABUSE.
8. Double-cliquez sur "ABUSE.EXE" pour d�marrer le jeu.


Notes :

Pour obtenir une liste des touches au clavier ou des commandes du jeu de la souris, appuyez simplement sur la touche "F1" � n'importe quel moment pendant le jeu.

Il est possible que le r�pertoire d'installation soit modifi� pendant l'installation et que le programme
cr�e un nouveau r�pertoire � votre place.

Vous pouvez SEULEMENT jouer � ABUSE � partir du disque dur. Le CD sert SEULEMENT � installer 
le jeu !

Cr�ez un raccourci ABUSE.EXE sur le bureau de Windows 95 pour d�marrer ABUSE rapidement.


3. Configurations sugg�r�es/Infos sur la disquette de d�marrage
-----------------------------------------


Pour un ordinateur de 8 Mo (ou plus)  :

"CONFIG.SYS"

DEVICE=C:\DOS\HIMEM.SYS
DOS=HIGH
(Ici, ajoutez votre gestionnaire de CD. Ex :  "DEVICE=C:\SCSI\ASPICD.SYS /D:ASPICD0"
FILES=40
BUFFERS=40
SHEll=C:\DOS\COMMAND.COM C:\DOS /P

"AUTOEXEC.BAT"

PATH=C:\DOS;C:\
PROMPT $P$G
(Ici, ajoutez votre gestionnaire MSCDEX.EXE. Ex : 
"C:\DOS\MSCDEX.EXE /D:ASPICD0 /M:12 /L:E"
C:\DOS\SMARTDRV.EXE 2048 (Ajoutez ceci apr�s l'installation, afin d'am�liorer la performance !)
(Ici, ajoutez votre gestionnaire de SOURIS. Ex : 
"C:\MOUSE\MOUSE.EXE")
SET COMSPEC=C:\DOS\COMMAND.COM
C:

NOTE :

Au cas o� vous ne pourriez pas disposer de suffisamment de m�moire conventionnelle pour jouer, 
essayez de charger le gestionnaire de m�moire DOS EMM386.EXE de la fa�on suivante. Les lignes DEVICEHIGH et LH doivent aussi �tre ajout�es pour lib�rer autant de m�moire que possible.
Vous devez aussi ajouter la ligne UMB � la ligne "DOS=HIGH".

Exemple :

"CONFIG.SYS"

DEVICE=C:\DOS\HIMEM.SYS
DEVICE=C:\DOS\EMM386.EXE NOEMS
DOS=HIGH,UMB
(Ici, ajoutez votre gestionnaire de CD. Ex :  "DEVICEHIGH=C:\SCSI\ASPICD.SYS /D:ASPICD0"
FILES=40
BUFFERS=40
SHEll=C:\DOS\COMMAND.COM C:\DOS /P

"AUTOEXEC.BAT"

PATH=C:\DOS;C:\
PROMPT $P$G
(Ici, ajoutez votre gestionnaire MSCDEX.EXE - Ex : "LH C:\DOS\MSCDEX.EXE /D:ASPICD0 /M:12 /L:E"
(Ici, ajoutez votre gestionnaire de souris. Ex : "LH C:\MOUSE\MOUSE.EXE")
SET COMSPEC=C:\DOS\COMMAND.COM
C:


NOTES suppl�mentaires  :

Si vous le souhaitez, vous pouvez retirer vos gestionnaires CD-ROM de votre configuration, une fois
l'installation r�ussie. Normalement, vous ne devrez le faire que si la m�moire basse pose un probl�me.


Si vous avez un CD-ROM SCSI, vous devez aussi ajouter la ligne concernant votre gestionnaire 
d'adapteur SCSI au-dessus de la ligne concernant le gestionnaire du CD. 
(Les CD fonctionnant avec une carte son doivent aussi charger le gestionnaire carte son avant la ligne du gestionnaire du CD.)

Ex : "DEVICE=C:\SCSI\ASPI8DOS.SYS /D /p234"
    "DEVICE=C:\SCSI\ASPICD.SYS /D:ASPICD0"

Pour que certaines cartes son fonctionnent correctement, vous devrez parfois charger des gestionnaires.  Ajoutez-les tels qu'ils apparaissent dans votre configuration normale. Le moyen le plus facile de le faire
consiste � cr�er une disquette de d�marrage en suivant les instructions ci-dessous et en laissant les 
lignes qui semblent avoir un rapport avec le son.

Si vous ne trouvez pas de gestionnaire de souris dans votre fichier AUTOEXEC.BAT, cherchez une 
ligne dans le fichier CONFIG.SYS comprenant "MOUSE.SYS". Cela fonctionnera aussi bien ; 
chargez-la de la m�me fa�on pour jouer � ABUSE.

Ex : "DEVICE=C:\DOS\MOUSE.SYS"

Si vous utilisez un programme de mise en ant�m�moire SMARTDRV.EXE, la vitesse du jeu sera consid�rablement am�lior�e, mais ce programme pourrait interf�rer avec la proc�dure d'installation. Nous vous conseillons d'installer 
le jeu, d'abord sans SMARTDRV, puis d'ajouter le programme ant�m�moire apr�s vous �tre assur� que l'installation est r�ussie (c'est-�-dire, lancez d'abord le jeu une premi�re fois sans le programme d'ant�m�moire !). 

Comme ABUSE utilise une unit� d'extension DOS pour la gestion m�moire, le jeu doit pouvoir �tre 
tourn� avec plusieurs configurations diff�rentes. En cas de difficult�s, nous vous conseillons de cr�er une disquette de d�marrage. Pour ne pas prendre de risques, cr�ez une disquette de d�marrage AVANT d'installer le jeu, afin de vous assurer que la configuration est correcte ! (G�n�ralement, les utilisateurs 
de Windows 95 n'auront pas besoin de cr�er une disquette de d�marrage.)

Pour cr�er une disquette de d�marrage pour le jeu :

1. Ins�rez une disquette vierge dans le lecteur A.
 
2. A l'invite "C:\", tapez "FORMAT A:/S".( "SYS A:" peut �tre utilis� � la place de cette 
commande si le disque est  PRE-FORMATE)

3. Une fois que le formatage est termin�, tapez "COPY C:\CONFIG.SYS A:"

4. Tapez "COPY C:\AUTOEXEC.BAT A:"

5. Tapez "EDIT A:\CONFIG.SYS", puis �ditez votre fichier de fa�on � ce 
que sa configuration ressemble autant que possible � celle ci-dessus. Tapez "REM" 
en face de chaque ligne qui ne semble pas n�cessaire. 
EX : "REM C:\WINDOWS\IFSHLP.SYS".

6. Sauvegardez le fichier modifi� en utilisant le menu "FICHIER" de l'�diteur
pour "SAUVEGARDER", puis SORTEZ. Utilisez votre souris si vous en avez une.

7. Tapez "EDIT A:\AUTOEXEC.BAT" et modifiez ce fichier de la m�me fa�on
que le fichier CONFIG.SYS. 

8. Sauvegardez et sortez du fichier AUTOEXEC.BAT.

9. REINITIALISEZ votre syst�me, puis d�marrez le jeu !


NOTES :

Si voulez que votre disquette de d�marrage lance automatiquement le jeu, ajoutez les lignes suivantes en bas de votre fichier AUTOEXEC.BAT :

C:
CD ABUSE
ABUSE

Bien entendu, changez ces lignes de fa�on � refl�ter le lecteur et/ou le r�pertoire appropri�, si vous 
avez sp�cifi� un LECTEUR et/ou un REPERTOIRE diff�rent pendant la proc�dure d'installation.


4.Installation de la carte son 
-----------------

La premi�re fois que vous lancez ABUSE.EXE, l'utilitaire de son SETUP.EXE devrait
lui aussi �tre lanc� automatiquement. Si vous souhaitez changer vos valeurs, ou que
l'�cran pour r�gler les valeurs son n'appara�t pas, tapez simplement "SETUP" dans le r�pertoire
ABUSE pour commencer manuellement la proc�dure. Une fois que vous �tes dans l'�cran
de r�glages, utilisez les touches FLECHEES pour mettre vos s�lections en surbrillance
et la touche ENTREE pour les s�lectionner. Les options de r�glages pour les cartes son  
DIGITAL et MIDI s'y trouvent, et la carte DIGITAL (seulement !) peut �tre AUTO-DETECTEE
par le programme. Utilisez l'AUTO-DETECTION, sauf si vous �tes certain des valeurs particuli�res
� votre carte. Si pour une raison quelconque, la proc�dure de d�tection �choue, essayez simplement 
de lancer l'utilitaire � nouveau (une m�thode diff�rente de d�tection sera utilis�e), et si votre syst�me
se bloque durant la proc�dure, r�initialisez le syst�me et essayez � nouveau. Utiliser "TEST" est une 
bonne habitude, pour vous assurer que tous les dispositifs fonctionnent correctement. Une fois que votre dispositif est correctement install�, assurez-vous de s�lectionner OK pour sauvegarder votre 
configuration. Vous pouvez aussi s�lectionner "ANNULER" � n'importe quel moment, pour ABANDONNER la proc�dure d'installation sans sauvegarder la configuration actuelle.

NOTES :

Vous devez disposer d'un dispositif sonore sp�cialis� MPU-401General MIDI pour pouvoir
entendre la musique dans le jeu. Une carte Soundblaster seule lira 
seulement les effets sonores num�riques. (sauf la carte SB/AWE32 qui fonctionnera correctement
NON SEULEMENT pour les effets num�riques, MAIS AUSSI pour la musique.). 
Les cartes-filles MPU-401 compatibles devraient aussi fonctionner pour la MUSIQUE.

N'essayez pas d'AUTO-DETECTER une carte son si vous n'en avez pas !


5.Support technique/Aide
--------------


Si vous avez besoin d'aide avec ABUSE, veuillez pr�parez les informations requises ci-dessous 
et appelez-nous � un des num�ros indiqu� au bas de ce document. A titre d'informations, nous 
Nous vous fournirons une aide � titre gratuit, les seuls frais que vous aurez � payer seront ceux 
de la communication t�l�phonique.
Veuillez nous procurer les informations suivantes : 

1. Une copie EXACTE du fichier CONFIG.SYS et AUTOEXEC.BAT avec lesquels vous avez 
INSTALLE et LANCE le jeu. 
2. La marque et le type d'unit� centrale que vous utilisez.
3. La marque et la version DOS que vous utilisez.
4. La marque et le type de carte vid�o que vous utilisez (et le N� du gestionnaire de version, si vous en    utilisez un).
5. La marque et le type de carte(s) son.
6. La marque et le type de votre CD-ROM (et les N� de versions des gestionnaires).
7. Une liste de tous les codes d'erreur que vous obtenez .
8. Une liste de tous les autres dispositifs c�bl�s de votre ordinateur (une liste de leurs valeurs
  serait aussi tr�s utile !).
9. Une liste du mat�riel et gestionnaires de r�seau, le cas �ch�ant.


Support technique :

Service Consommateurs d'Electronic Arts : 72-53-25-00
FAX : 72-53-25-08
Minitel : 3615 EADIRECT
E-mail : support@origin.ea.com (anglais uniquement)

