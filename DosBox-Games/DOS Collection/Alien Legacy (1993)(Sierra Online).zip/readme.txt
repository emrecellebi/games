
                              Alien Legacy

                     Install Utilities Release Notes

                            December 2, 1994


This is the boot disk maker and patch utility disk for Version 1.00 of
Alien Legacy.  This README file contains extra information about the boot
disk maker, patch utility and Alien Legacy in general.  It also contains
a reprint of the information listed on the insert included with this
disk.

The patch will update Alien Legacy to version 1.01.  This updated version
corrects all identified technical issues in version 1.00 of Alien Legacy.
Please be sure to read this entire readme file for additional information
not covered in the Trouble Shooting section of the game's manual.

Table of Contents

1.  INSTALL UTILITY DISK LIMITATIONS
2.  PLAYING OLD SAVED GAMES
3.  SMARTDRIVE DISK CACHING
4.  INSTALLING THE PATCH
5.  MANUAL PATCH INSTALLATION
6.  CREATING A BOOT DISK
7.  CYRIX CPUS
8.  TECHNICAL SUPPORT

-------------------------------------------------------------------------
1.  INSTALL UTILITY DISK LIMITATIONS

If you have a version of Alien Legacy other than Version 1.00, you can
still use the boot disk maker, but do not use the patch included on this
disk.  If you are uncertain of what version you have, check the floppy
disk labels on the game disks.  Once the patch has been successfully
installed and applied, you will have Version 1.01.

Instructions on how to use the boot disk maker are provided in the
section titled CREATING A BOOT DISK.  To install and apply the patch,
please refer to the section titled INSTALLING THE PATCH.

-------------------------------------------------------------------------
2.  PLAYING OLD SAVED GAMES

If you have saved games from Alien Legacy Version 1.00, and have
installed the patch from this Install Utilities disk, you should be able
to continue the saved games using Version 1.01.  The patch will not be
able to correct any problems caused by corrupted game files or corrupted
saved games.  

If you encounter problems restoring your saved games with version 1.01, 
you should make a boot disk and play the game from the boot disk, (see 
section 6).  The boot disk will resolve most conflicts.

If you still encounter a lockup, you should backup your saved games to a
floppy disk and reinstall the game and patch in the boot disk environment.
To backup the saved games, type:

CD\Sierra\alien\saves [enter]
Copy . a: [enter]

After you copy your saved games to a floppy disk, delete the game's dir-
ectory from your hard drive.  Now boot your computer with the bootdisk and
reinstall the game and the patch. 

Once you have finished installing the game, copy the saved games from the
floppy disk into the \Sierra\Alien\Saves directory on your hard drive. You
can do this by typing:

copy a:\. c:\sierra\alien\saves [enter]

If you are still unable to restore saved games, the saved games are likely 
corrupted.  You should restore to a previous saved game or start a new game.

-------------------------------------------------------------------------
3.  SMARTDRIVE DISK CACHING

Performance improvements may be obtained by using a disk caching utility
such as SMARTDrive.  It is highly recommended that a disk caching utility
is installed with at least a 512K cache size to speed file operations.
Please consult your MS-DOS documentation or your disk caching utility's
documentation for information about setting up a disk cache on your
computer system.  If you have SMARTDrive available and wish to install
it, create a boot disk using the boot disk maker provided on this disk.
Then, edit the AUTOEXEC.BAT file on the Boot Disk.  (Make sure you are
editing the file on the Boot Disk and not the AUTOEXEC.BAT file on your
hard drive!)  At the end of the file add this line:

C:\DOS\SMARTDRV.EXE c 512 512

Reboot using the Boot Disk and you will be ready to play Alien Legacy.

There are numerous versions of SMARTDrive and other disk caching software
available.  You may experience some loading problems with certain earlier
versions of SMARTDrive.  If you experience problems related to loading
and saving, or extremely slow disk access during gameplay, try a later
version of SMARTDrive.

-------------------------------------------------------------------------
4.  INSTALLING THE PATCH

After your Alien Legacy manual and diskettes were printed, we developed a
helpful game "patch" that is included on the "Install Utilities" disk.
Follow the steps listed below to upgrade your installed copy of Alien
Legacy Version 1.00 to Version 1.01.  If you are experiencing problems
using the Install Utilities INSTALL program to install the patch, please
refer to the section titled MANUAL PATCH INSTALLATION.

1.  Install the game as described in the manual pages 7-8.  NOTE:  If you
      already have the game installed you may skip this step.
2.  Insert the "Install Utilities" disk in the appropriate drive, type
      the drive name (usually A:) and press [Enter].
3.  Type INSTALL and press [Enter].  Make sure the indicated game
      directory is correct (it should contain Alien Legacy Version 1.00).
4.  From the Installation Choices menu, select "Install Patch to the
      Indicated Directory."
5.  From the game directory, type PATCH and press [Enter] to upgrade the
      game.

Starting Alien Legacy

To start the game, type AL in the directory where you installed the game
(SIERRA\ALIEN is the default).  If you have difficulties getting the game
to start properly (this is usually due to a lack of free memory
available), please refer to the section titled CREATING A BOOT DISK.

-------------------------------------------------------------------------
5.  MANUAL PATCH INSTALLATION

If you are experiencing problems using the Install Utilities INSTALL
program to install the patch, the following instructions will allow you
to manually copy the patch to your hard disk drive.

1.  Check your hard disk drive and confirm that you have at least 205K
    (209920 bytes) of disk space available.  You might need more if you
    are using a disk compression utility such as Stacker or
    DoubleSpace/DriveSpace.  Also, make sure that you do not have any
    lost allocation units or other errors on the hard drive.  These
    errors may cause the patch to not install correctly.  To find errors
    on the drive, use CHKDSK.  If any errors exist, they will appear as
    the first line below the Serial Number.

    If you have errors, you will need to correct them.  To do this, you
    can use the CHKDSK /F command.  WARNING:  There is a slim chance that
    you may lose data off of the hard drive when attempting to correct
    any errors.  The chance of data loss depends upon the severity of the
    errors on the drive.  Consult your MS-DOS or hard drive maintenance
    utility documentation for more information.  We highly recommend you
    make a back-up of your hard drive and/or back-up any important
    information or documents before attempting to correct hard drive
    errors.

2.  Copy the two files called PATCH.EXE and PATCH.RTP from the Install
    Utilities disk to the directory where you have Alien Legacy Version
    1.00 installed.  For example, if the Install Utilities disk is in
    drive A: and the game is installed to directory C:\SIERRA\ALIEN, you
    would type:

      C: [ENTER]
      CD \SIERRA\ALIEN [ENTER]
      COPY A:\PATCH.EXE [ENTER]
      COPY A:\PATCH.RTP [ENTER]

3.  After the two files have been copied, apply the patch by changing to
    the game directory and starting the PATCH utility.  Continuing with
    the commands listed above, you would type:

    PATCH [ENTER]

    If the PATCH utility was successful, your copy of Alien Legacy should
    now be Version 1.01.  The game can be started as usual (i.e. by
    typing AL then pressing [ENTER] from the game directory).

-------------------------------------------------------------------------
6.  CREATING A BOOT DISK (replaces manual section pages 79-80)

If your current system set-up doesn't provide enough free memory to
start the game, try making a boot disk.  A boot disk lets you easily
re-configure your computer's memory for running Alien Legacy without
affecting your current system set-up.

Before you start, have a blank or formattable floppy disk for your A:
drive ready.  (Any files on it will be erased.)  Note:  The boot disk
will work only in the A: drive.

1.  Insert the "Install Utilities" disk in the appropriate drive, type
      the drive name (usually A:) and press [Enter].
2.  Type INSTALL and press [Enter].  Make sure the indicated game
      directory is correct.
3.  From the Installation Choices menu, select "Make Bootable Floppy
      Disk."  Follow the on-screen instructions carefully.
4.  When your boot disk is complete and the Installation Choices menu
      reappears, select "Cancel Installation and Return to DOS."

Using a Boot Disk

To use the boot disk, start (or restart) your computer with the boot
disk in the A: drive, and then start the game.  If the game still will
not run, or the drivers for your mouse or sound card don't load
correctly, you'll need to customize the start-up files manually.

Customizing Your Boot Disk

To customize a boot disk, you can edit the CONFIG.SYS and AUTOEXEC.BAT
start-up files on the boot disk that the Install program created, or
create a new Boot Disk from scratch.  CONFIG.SYS and AUTOEXEC.BAT are
simple text files that you can edit using your DOS Edit utility, the
Windows Notepad or your preferred word processor in its text-only mode.
Warning:  Manually altering the CONFIG.SYS and AUTOEXEC.BAT start-up
files can be a trial and error process.  When opening a file to edit,
triple-check to MAKE SURE you are working with the files on your boot
disk in the A: drive.  Otherwise, you may change the CONFIG.SYS and
AUTOEXEC.BAT files on your hard drive instead, which in turn may impair
the normal operation of your system.

Sample Boot Disk CONFIG.SYS File

If you need to customize the boot disk created by the Install program,
compare the CONFIG.SYS and AUTOEXEC.BAT files on your boot disk to the
following examples rather than the ones shown on manual pages 81-82.  The
lines in your start up files will differ according to your system's
drivers and directory names, and the version of DOS you use.  Other
differences may indicate places where you can remove a driver, load it
into upper memory, or change a device switch to use less memory.  As
always, refer to your system reference manuals if unsure about anything.

DEVICE=C:\DOS\HIMEM.SYS
DOS=HIGH  (Loads DOS into Upper Memory)
FILES=30
BUFFERS=20
BREAK=ON
DEVICE=C:\MOUSE\MOUSE.SYS
DEVICE=C:\DOS\DBLSPACE.SYS /MOVE  (Only if using DBSLSPACE)
DEVICE=C:\STACKER\STACHIGH.SYS  (Only if using Stacker)

Sample Boot Disk AUTOEXEC.BAT file

PROMPT Sierra Boot Disk $P$G  (From "Make Bootable Floppy Disk.")
PATH=C:\DOS
SET COMSPEC=C:\COMMAND.COM
C:\MOUSE\MOUSE.COM  (Only if you don't use MOUSE.SYS in CONFIG.SYS.)
C: (Changes to hard drive.)
CD \SIERRA\ALIEN (Changes to the Alien Legacy directory.)
AL (Starts Alien Legacy.)

-------------------------------------------------------------------------
7.  CYRIX CPUS

Some difficulties have been encountered by users who have Cyrix CPUs
installed in their computer.  The two types of problems that have been
identified are listed below.

1.  The Cyrix processor may have compatibility problems running DOS
    extender programs such as DOS/4GW (Alien Legacy uses DOS/4GW).

2.  Some older BIOS's may have conflicts with Cyrix processors that
    will cause unexplained lockups or other problems.

If you are experiencing problems relating to item #1, please call Cyrix
customer support at (800) 462-9749.  They can make arrangements for a
processor upgrade.

Beyond replacing the motherboard, there is no known work around for
item #2.

-------------------------------------------------------------------------
8.  Technical Support

If you continue to experience any problems, or if you have any questions
concerning any of the above steps, our Technical Support Team will be
more than happy to assist you.  Please call (206) 644-4343 between 8:15 a.m.
and 4:45 p.m., Pacific Standard Time, Monday through Friday,   We can be
reached by Fax at (206) 644-7697, or by mail at the following address:

Sierra On-Line
P.O. BOX 85006 
Bellevue, WA 98015-8506
Attention: Technical Support

You can also reach our Technical Support Team on one of the following
services:

Sierra BBS          (206) 644-0112 or telnet bbs.sierra.com  
Compuserve          GO SIERRA
America Online      Keyword: Sierra
Internet            support@sierra.com or http://www.sierra.com

Please outline the problems along with the specific information about your 
computer system, and we will gladly respond to your letter, fax, or BBS 
message as soon as possible.  When contacting us by fax or BBS please 
allow 24-48 hours for turnaround.  During weekends or holidays, there may 
be some delays.

To better serve our European customers with technical problems and disk 
replacements, Sierra U.K Customer Support or Coktel Customer Support can 
be reached at the following address:

Sierra On-Line Limited                  Coktel Vision
Unit 2, Theale Technology Centre,       Parc Tertiaire de Meudon
Station Road                            Immeuble "Le Newton"
Theale, Berkshire RG7 4AA               25 rue Jeanne Braconnier
United Kingdom                          92366 Meudon La For�t Cedex
Main: (44) 1-734-303171                 France
Fax : (44) 1-734-303201                 Main: (33) 1-46-01-4650
BBS : (44) 1-734-304227                 Fax : (33) 1-46-31-7172

Sierra Technical Support provides this documentation as a reference to 
Sierra customers using Sierra software products.  Sierra Technical 
Support makes reasonable efforts to ensure that the information 
contained in this documentation is accurate.  However, Sierra makes no 
warranty, either express or implied, as to the accuracy, 
effectiveness, or completeness of the information contained in this 
documentation.
     
SIERRA ON-LINE, INC. DOES NOT WARRANTY OR PROMISE THAT THE INFORMATION 
HEREIN WILL WORK WITH ANY OR ALL COMPUTER SYSTEMS.  SIERRA DOES NOT 
ASSUME ANY LIABILITY, EITHER INCIDENTAL OR CONSEQUENTIAL, FOR THE USE 
OF THE INFORMATION HEREIN, INCLUDING ANY AND ALL DAMAGE TO OR LOST USE 
OF COMPUTER HARDWARE OR SOFTWARE PRODUCTS, LOSS OF WARRANTIES, OR LOST 
DATA BY THE CUSTOMER OR ANY THIRD PARTY.  NO ORAL OR WRITTEN 
INFORMATION OR ADVICE GIVEN BY SIERRA, ITS EMPLOYEES, DISTRIBUTORS, 
DEALER OR AGENTS SHALL CHANGE THE RESTRICTION OF LIABILITY OR CREATE 
ANY NEW WARRANTIES.  IN NO CASE SHALL SIERRA'S LIABILITY EXCEED THE 
PURCHASE PRICE OF THE SIERRA SOFTWARE PRODUCT.
 