The Infocom Collection from Activision CD-ROM READ.ME file

5/17/95

This file contains additional information which may not be in the
printed Infocom Collection CD-ROM documentation.


FOR PC USERS ONLY
-----------------

To print this file on your printer, type:

	COPY README.TXT PRN

All company or product names are trademarks, registered trademarks
or service marks of their respective owners.


INSTALLING FROM MS-DOS
----------------------

While Activision recommends that you install and run The Infocom 
Collection in Windows, it can be installed via DOS instead.

To install from MS-DOS 5.0 or later, type the following at the 
prompt:
 
	xcopy d:\pc\adventur\*.* c:\infocom\adventur\ /s

where "adventur" is the name of the Infocom Collection to be
installed (i.e. mystery, sci-fi, fantasy, comedy or adventure.)


FOR PC AND MACINTOSH USERS
--------------------------


CUSTOMER SERVICE INFORMATION
----------------------------

	To purchase this and other Activision/Infocom titles,
	please contact your local retailer, or in the U.S. call
	1 (800) 477-3650.

If you have any comments, questions or suggestions about Infocom 
Collection or any other Activision product, you can contact us at
(310) 479-5644 between the hours of 9:00 a.m. and 5:00 p.m. 
Pacific Time, Monday through Friday, (except closed on holidays) 
or you can contact a customer service representative through the 
following on-line services:

Activision BBS: (310) 479-1335
		*   Available 24 hours a day
		*   Up to 14,400 Baud
		*   Settings: 8 Bits, No Parity, 1 Stop bit
                             (8,N,1)

CompuServe:     76004,2122 or [GO GAMEPUB] in the Game Publishers
                Forum B

Prodigy:        ACTI10B

GEnie:          ACTIVISION

America OnLine: MEDIAJAKE or use keyword "ACTIVISION" to locate 
                the Activision Forum

Internet:       support@activision.com

World Wide Web: http://www.activision.com

--------------------- END OF FILE ---------------------
