			    ---- ALIEN LOGIC README ----
				   v1.00 11/13/94

IMPORTANT NOTES:

Running with the /G option may cause occasional mouse disruptions.

Running with the /Knn option on the command line causes CD music to
end earlier according to a specified time. For example: 

		   ALIEN /K50   <Enter>
		   
will restart music five seconds early. This switch may be necessary when 
the game is run on certain CD-ROM drives.


--** The Collected Journals of Thriddle Jorunologist Bennid Go-Wogo **--

Volume 9
Chapter 37 - Ardoth and Its Environs
Section 93B - On the Quality and Availability of Ardothian Social Services
Subsection XP-41 - Hospital Services
Part XIV - A Recollection of the Details of a Conversation Held With a Local
Bronth Healer:

From what I could ascertain, it appears that said healer is highly skilled in
treating a large variety of wounds and injuries.  However, it should be
remembered that said healer is incapable of diagnosing the complete extent of
a patient's injuries.  The healer will always attempt to offer aid, even if
such aid is incapable of assisting the patient in any way, given the more
advanced state of said patient's wounds.  By consulting the Mountain Crown
Human Biology Injury Tracking Chart, one can see that first aid will only heal
injuries of the light green sort, medication will heal injuries rated at an
orange level or lower, while surgery will heal all wounds of any sort.

Travelers should be reminded that all healing services are rendered upon
request.  Payment for services rendered is exacted regardless of the
effectiveness of said services.
