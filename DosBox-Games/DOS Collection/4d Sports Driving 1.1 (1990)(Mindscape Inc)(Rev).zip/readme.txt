
-----------------------------------------------------------------------------
        KHR's & JTK's Stunts/4D-SportsDriving Competition

                   http://www.kalpen.de/stunts
-----------------------------------------------------------------------------

Hello, you just downloaded the old yet coolest racing game of the world!


Please follow these instructions for successfull setup:

1. Copy the whole archive in one folder (e.g. "Stunts").

2. Run "setup.exe".

3. Setup "Video Display:" Choose MCGA/VGA graphics or lower.

4. Setup "Sound option:" Choose your sound card.

5. DO NOT ACTIVATE THE "Install game to hard disk:" OPTION (GAME IS ALREADY
   INSTALLED)!

6. "Exit".


7. If you downloaded Stunts! version:

   Broderbund 1.0 start with "st.com" to disable the security option,

   Broderbund 1.1 start with "stunts_k.exe" (...),
   
   Mindscape 1.0  start with "stunts.com", this version is already cracked.  

   Mindscape 1.1  start with "st.com" or "Stunts_k.exe".


8. RACE!!!

9. Go to our Stunts! homepage at http://www.kalpen.de

10.Enter the contest!


CU at our scoreboard!

-----------------------------------------------------------------------------
For any questions about the contest, the tracks, our sites or what so ever 
write to:
KHR (e.g. Markus Kalpen): mkalpen@okay.net
JTK (e.g. Oliver Kalpen): kalpen@ewf.uni-kiel.de
_____________________________________________________________________________


Thanks for visiting our sites and entering the contest!
We really appreciate this!
