                        A L I E N   R A M P A G E

=======================================================================
--------------  Read this! --- Read this! --- Read this!  -------------
=======================================================================

Audio Setup
-----------
The first time you run Alien Rampage, you will see the following menu:

     KEYBOARD
     GAMEPAD
     JOYSTICK
     SOUND
     FINISHED

You MUST go into the SOUND menu to set-up your sound card! Select the
type of sound card you have, then press "N" to the question "Modify
these values?" and the sound card should be initialized.

 If it's not and you can't get the sound card to work, read the
TECHINFO.TXT file for more help.

