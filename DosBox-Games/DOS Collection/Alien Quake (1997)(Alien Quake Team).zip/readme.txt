
                        **************************
                        * ALIEN QUAKE - 1.0 BETA *
                        **************************

        O.k here it is - Alien Quake 1.0 Beta...Try it out - let us know
what you think.  The official release is March 31, 1997 for Alien Quake
Episode 1 - 'Return to Lv-426'.  There are 11 levels, plus a secret level,
and some D.M. levels on the way.  All new weapons, enemies, graphics etc,
plus new sounds and ai.  This should do for Quake what Aliens TC did for
Doom, only better.


Make a dir in Quake called aliens, copy all the zips in there and pkzip -d
zips.  To run it type quake -game aliens...

Contacts.

jdiamrulz@aol.com
nv91-gta@nada.kth.se
dwallin@juno.com
