[edit-]
screen=80 50
toggles=1 0 0 1 0 0
srch=
src=
rpl=
file=d:\alien\state.rst 1 1 1 7
[brief]
file=d:\alien\state.rst 1 1 1 1 1 47 78 1 c=0
[shared-]
pmark=d:\alien\state.rst 1 11
