Alien Carnage  (aka Halloween Harry)  version 1.0
Full version with all 4 Missions.
Platform/Action for DOS or Windows 9x
Keyboard input.

Upacking the archive:
-Just create a directory on your hard drive and unzip the download into it.
Close up your .zip extraction program.
-Change to the directory you unzipped the download into and run ALIEN.EXE
to unpack the game. This may take a while on some systems, just be patient.

Playing the game:
Run CARNAGE.EXE to start the game.

Press the F1 key to access Game Options and in-game instructions.

Have fun!
Repacked by Joan O. Arc for Home of the Underdogs. September 2001
Visit us at http://www.theunderdogs.org/