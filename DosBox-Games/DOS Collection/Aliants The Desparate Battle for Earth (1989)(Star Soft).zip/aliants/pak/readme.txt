         EARTH...2301 A.D.

    Man had finally learned to live 
in peace.  For the past 200 years, 
the nations of Earth had gathered 
under one government and one flag. 

    Freed from war, Man set his 
sights higher.  Where men had once 
conquered men, now they conquered 
Space.  In time, pioneers settled on 
thirteen colonies, spread throughout 
the solar system. 

    It was Man's greatest golden 
age, but it was destined to be... 

          DESTROYED! 

&
&
           2301 A.D. 

    From a remote part of the 
galaxy, menacing ships silently make 
their way towards an unsuspecting 
Earth. 

&
    Swarms of alien vessels approach 
their prey... 
 
&
    ...until they reach their final 
destination, the future slave planet 
EARTH. 
 
&
&
    Space station scientists launch 
a probe to gather information on the 
strange new objects in our solar 
system... 
 
&
&
    ...the probe sends a message to 
warn the Earth of the impending 
doom... 
 
&
&
    The probe starts its message, 
then suddenly stops; all that is 
heard is silence. 
 
&
&
    The people of Earth launch the 
few ships they have in an attempt to 
ward off the invading force... 

& 
&
    ...but to no avail.  They were 
outgunned, outnumbered, and easily 
blown from the sky. 
 
&
    Earth's defensive weapons had 
been scrapped years ago.  Earth 
could do little as the invaders 
landed and began their occupation. 
 
&
    Soon, all of civilization is 
conquered... 
 
&
    As the alien, ant-like creatures 
start their occupation of the 
planet, Man sees the face of his 
oppressors.  The look like humanoid 
insects...Man calls them "ALIANTS"! 
 
&
    Their armies march across the 
continents of Earth, wiping out all 
resistance.  The last remaining 
leaders of the Earth Government flee 
to a secret base in the asteroid 
belt, which they call Valley Forge.  
From there, they begin their plans 
to retaliate, no matter how long or 
how hard the struggle... 
 
&
    At first, little is known about 
the ALIANTS, but soon their social 
structure becomes obvious. 
 
    ALIANTS are divided in to three 
groups, or classes... 
 
&
    Worker ALIANTS are the backbone 
of the society.  They perform all 
the daily functions necessary for 
ALIANT life... 
 
&
    Soldier ALIANTS are the perfect 
fighting machines.  They have only 
one goal in life, to enforce the 
rules of the Aliant race.  Bred to 
be merciless, the Soldiers fear no 
one but their leaders. 
 
&
    Imperial ALIANTS are the 
smartest and most dangerous.  They 
provide the military  genius for the 
ALIANT war machine... 
 
&
&
    Humans have been forced to work 
for the ALIANT invaders, building 
more war ships for the future race 
of conquerors... 
 
    ...conquerors even now being 
incubated in ALIANT pods all over 
the EARTH... 
 
&
    ...Pods that must be taken care 
of for a hundred years before the 
minds of these new soldiers are 
completely formed. 
 
&
    The last ten years of incubation 
is done within liquid memory tanks.  
This technique produces the perfect 
ALIANT soldier, memories intact  and 
ready to fight. 
 
&
&
    Through spies on Earth, it is 
learned that the ALIANTS plan to use 
Earth to grow a completely new army 
of soldiers.  These soldiers will be 
given enormous power. 
 
&
    The ships themselves are being 
built by human slaves on Earth, but 
the power crystals for them must be 
brought from the home planet of the 
ALIANTS, a planet Man later calls 
INSECTUS. 
 
    It was learned that the Crystal 
Ship is on the way to Earth, 
bringing the power crystals needed 
to power the new ALIANT fleet. 
 
&
&
    Although Earth itself was 
captured, none of the 13 colonies 
scattered throughout the solar 
system were attacked.  This may have 
come from overconfidence on the part 
of the ALIANT leaders, but it left 
the door open for spyteams to return 
secretly, and occasionally come away 
with something of value. 
 
    One such expedition found a 
thrown-away power crystal.  With it 
came hope. 
 
&
    MAYBE WE'RE NOT DOOMED AFTER 
ALL!!! 
 
&
    That last power crystal gives 
us a chance to power at least one 
mission.  Plans are made to 
intercept the ALIANT crystal ship as 
it comes out of warp beyond the Sun. 
 
    Valley Forge has been chosen as 
the base for the Earth Force 
counterattack... 
 
    The call goes out to all you 
Bullet pilots.  The time has come to 
regain the planet we rightfully call 
Home. 
 
    Courage is needed... Only the 
BEST need apply.







