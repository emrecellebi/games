

README.TXT

by Sean Mustakas


Contents
---------

1.System Requirements

2.Installation

3.Suggested Configurations/Boot Disk Info

4.Soundcard Setup

5.Support/Help


1.System Requirements
---------------------

In order to play ABUSE, you should have at least: 

Intel 486/DX2-50 CPU or 100% Compatible
MS DOS 5.0 or higher or Windows 95
8 MB RAM
400K Free Conventional Memory
13 MB Free Hard Drive Space
1 MB 256 Color VGA Video Card 
MS Mouse or 100% Compatible (with MS or 100% Compat. Driver)
CD-ROM Drive (for installation to HD only)

Network Play(2-8 Players):

Intel 486/DX2-66 CPU or 100% Compatible
Windows 95
Homogenous IPX Compatible Network / Drivers

Sound(optional): 

Soundblaster or 100% Compatible Soundboard for Digital SFX
Roland MPU-401 General MIDI or 100% Compatible Soundboard for MIDI Music


2.Installation
--------------

To Install ABUSE -

DOS :

1.Place the CD into your CD-ROM drive.
2.Switch to the CD's drive letter. (type "D:" or "E:" typically)
3.Type "Install"
4.Follow the on-screen prompts

To start playing ABUSE -

1.Switch to the ABUSE directory.
2.Type "ABUSE"

ex.

C:
CD ABUSE
ABUSE

Windows 95 :

1.Place CD into your disc drive.
2.Double Click the "My Computer" Icon.
3.Double Click your CD-ROM's drive letter(usually "D" or "E")
4.Double Click "INSTALL.EXE".
5.Follow the On-Screen instructions.(Must Use Keyboard in DOS Box)
6.Return to the "My Computer" window and Double Click the drive letter
  that you installed ABUSE on.("C" by default)
7.Double Click the ABUSE folder.
8.Double Click "ABUSE.EXE" to start the game.


Notes -

For a list of Game Key/Mouse Commands, simply hit the "F1" key at anytime 
during gameplay.

The installation directory may be changed during the install, and the program
can create the new directory for you.

ABUSE can ONLY be played from the Hard Drive. The CD is for Installation
ONLY!

Create an ABUSE.EXE shortcut on your Windows 95 desktop to start ABUSE
quickly.


3.Suggested Configurations/Boot Disk Info
-----------------------------------------


For an 8 MB(or more) Machine -

"CONFIG.SYS"

DEVICE=C:\DOS\HIMEM.SYS
DOS=HIGH
(Add your CD device driver here - ex. "DEVICE=C:\SCSI\ASPICD.SYS /D:ASPICD0")
FILES=40
BUFFERS=40
SHEll=C:\DOS\COMMAND.COM C:\DOS /P

"AUTOEXEC.BAT"

PATH=C:\DOS;C:\
PROMPT $P$G
(Add your MSCDEX.EXE driver here -ex."C:\DOS\MSCDEX.EXE /D:ASPICD0 /M:12 /L:E")
C:\DOS\SMARTDRV.EXE 2048 (add this after Install to improve performance!)
(Add your MOUSE driver here - ex. "C:\MOUSE\MOUSE.EXE")
SET COMSPEC=C:\DOS\COMMAND.COM
C:

NOTE -

In the event that you can't get enough Conventional Memory to play the game,
try loading DOS's memory manager EMM386.EXE as follows. DEVICEHIGH and LH
statements should be added as well to free up as much memory as possible.
The UMB statement should also be added to the "DOS=HIGH" line.

ex.

"CONFIG.SYS"

DEVICE=C:\DOS\HIMEM.SYS
DEVICE=C:\DOS\EMM386.EXE NOEMS
DOS=HIGH,UMB
(Add your CD device driver here -ex."DEVICEHIGH=C:\SCSI\ASPICD.SYS /D:ASPICD0")
FILES=40
BUFFERS=40
SHEll=C:\DOS\COMMAND.COM C:\DOS /P

"AUTOEXEC.BAT"

PATH=C:\DOS;C:\
PROMPT $P$G
(Add your MSCDEX.EXE driver here -ex."LH C:\DOS\MSCDEX.EXE /D:ASPICD0 /M:12 /L:E")
(Add your MOUSE driver here - ex. "LH C:\MOUSE\MOUSE.EXE")
SET COMSPEC=C:\DOS\COMMAND.COM
C:


Additional NOTES -

Your CD-ROM drivers may be removed from your configuration after a successful
install, if desired. You should only have to do this if Low Memory becomes an 
issue.

If you have a SCSI CD-ROM, you should also add your SCSI Adapter's driver
above the CD Driver line.(Soundcard driven CDs should similarly load the
Soundboard driver before the CD line.)

ex. "DEVICE=C:\SCSI\ASPI8DOS.SYS /D /p234"
    "DEVICE=C:\SCSI\ASPICD.SYS /D:ASPICD0"

Some Soundboards may require that you load drivers in order to function
properly. Add them as they appear in your normal configuration. The easiest
way to do this is to make a Boot Disk following the directions below, leaving
in any line that seems sound related.

If you fail to find a mouse driver in your AUTOEXEC.BAT, look in the
CONFIG.SYS for a line that has "MOUSE.SYS" in it. This will work just as
well, and should be loaded in the same manner to play ABUSE.

ex. "DEVICE=C:\DOS\MOUSE.SYS"

Using the disk cache SMARTDRV.EXE can greatly improve game speed, but it can
sometimes interfere with the installation process. We recommend the game be
installed without SMARTDRV first, then add the cache after verification of
a successful install(ie. run the game once first!). 

Since ABUSE uses a DOS Extender for memory management, it should run under
a variety of different configurations. In the event your's doesn't work, we
suggest the creation of a Boot Disk. To be safe, create a Boot Disk BEFORE
you install the game to insure proper configuration! (Windows 95 users will
generally Not need to make a Boot Disk.)

To make a BOOT DISK for the game-

1.Put a blank floppy disk in your "A" drive.

2.From the "C:\" prompt, type in "FORMAT A:/S".( "SYS A:" may be used in 
  place of this command if the disk is PRE FORMATTED)

3.After the format is complete, type in "COPY C:\CONFIG.SYS A:"

4.Type in "COPY C:\AUTOEXEC.BAT A:"

5.Type in "EDIT A:\CONFIG.SYS", then edit your file to resemble the above
  configurations as closely as possible. Put "REM" in front of any line
  that doesn't seem necessary - EX. "REM C:\WINDOWS\IFSHLP.SYS".

6.Save the modified file by using the editor's "FILE" menu to "SAVE" and
  then "EXIT" - use your mouse if present.

7.Type in "EDIT A:\AUTOEXEC.BAT" and modify this file in the same manner as
  the CONFIG.SYS. 

8.Save and exit the AUTOEXEC.BAT.

9.REBOOT your system, then start the game!

NOTES -

If you want your Boot Disk to automatically start ABUSE for you, add these
lines to the bottom of your AUTOEXEC.BAT:

C:
CD ABUSE
ABUSE

Of course, change these lines appropriately if you specified a different
DRIVE and/or DIRECTORY during the install process.


4.Soundcard Setup 
-----------------

The first time that ABUSE.EXE is run, the sound utility SETUP.EXE should
run automatically as well. If you wish to change your settings or the
sound setup screen doesn't appear, simply type "SETUP" within the ABUSE
directory to manually start the process. Once in the setup screen, use the
ARROW keys to highlight your selections and the ENTER key to choose them.
Setup options for both a DIGITAL and a MIDI soundboard are present, and the
DIGITAL(only!) card may be AUTO-DETECTED by the program. Unless you are
certain of your particular card's settings, AUTODETECT is the way to go.
If for any reason the detection fails, simply try the utility again (a
different detection method will be used), and if your system locks up at
any time during the process, reboot the system and try again. It is a good
practice to use "TEST" to insure all devices are functioning properly.
Once your device is set up properly, make sure to select "OK" to save
your configuration. You may also select "CANCEL" at any time in order to
ABORT the setup process without saving the current configuration.

NOTES-

You must have a dedicated MPU-401 General MIDI sound device in order to
hear MUSIC in the game - a Sound Blaster by itself will only play back
Digital Sound Effects(except for the SB/AWE32 which will function properly
as BOTH a Digital and Music source). MPU-401 compatible Daughtercards should
work as well for MUSIC.

Do not try to AUTODETECT a soundcard if you don't have one!


5.Support/Help
--------------


If you find yourself in need of assistance with ABUSE, please have the info
requested below handy and use the support method of your choice. FYI, we do
not charge for Tech Support, but long distance charges will apply normally.

Please Have - 

1.An EXACT copy of the CONFIG.SYS and AUTOEXEC.BAT that you INSTALLED/RAN
  our product with.
2.The Brand and Type of CPU that you are using.
3.Your Brand and Version of DOS.
4.Your Brand and Type of Video Board(and Driver Version # if applicable).
5.Your Brand and Type of Sound Board(s).
6.Your Brand and Type of CD-ROM (and Driver Version #s).
7.A list of any Error Codes encountered.
8.A list of any other hardware devices present on your system (any device
  settings that you can find will certainly help as well!).
9.A list of Network Drivers and Hardware(if applicable).


Support -

Origin Product Support - (512)434-HELP or (512)434-4357
Origin FAX             - (512)795-8014
Origin BBS             - (512)346-2BBS or (512)346-2227
Internet FTP           - support@origin.ea.com

