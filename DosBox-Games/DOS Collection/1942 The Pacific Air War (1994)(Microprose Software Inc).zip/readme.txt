1942: THE PACIFIC AIR WAR

Machine Requirements:
--------------------

   To run 1942: The Pacific Air War, you will need:

      1) A 386 SX processor (386 DX 33 MHz or higher recommended)
      2) 570k free conventional memory
      3) 1.5 Meg free EMS memory
      4) 16 MB free hard disk space
      5) Joystick or mouse

NOTE  - 1942: The Pacific Air War has not been
        tested under Microsoft Windows

Design Changes
--------------

During the ongoing playtest process, we made design adjustments
that could not be included in the manual or technical supplements.
The following is a list of these changes:


1. Autopilot
   When flying in traning mode, the autopilot key will enable full
   computer control of your aircraft.  The autopilot will land,
   divebomb, and make torpedo runs.  We encourage you to use this
   feature to learn how to perform difficult manuevers (such as
   carrier landings!).

   When not in training mode, your autopilot will only takeoff,
   maintain formation on the way to and from the target, and fly
   your patrol route on CAP.  Landing, dogfighting, divebombing,
   and torpedo bombing must be done by you.

2. Kill Credits
   Pilots are given credit for a kill based on the percentage of
   damage they inflicted on the plane.  If two pilots damaged the
   same enemy plane, the pilot who inflicted the most damage will
   get credit for the kill.  So you may not receive credit for a
   kill even if you are the last pilot to damage a plane.

3. Ditching
   Planes can be successfully ditched in the ocean.  You need to
   hit the water at a very slow speed (stall the plane below 50 
   ft.).  During a pilot career, ditching will be treated the same
   as if you bailed out (you will be rescued, captured, or killed).
   
4. Setting Cruising Altitudes
   When a strike flies to a target, there is always a lead flight
   that everyone else follows.  For mutual fire support reasons,
   the flights in a strike stay close to each other until they
   reach their target.  Because of this, you may only adjust the
   cruising altitude of the lead flight.  All other flights will
   automatically adjust their cruising altitudes to match.

5. Freeing Up Hard Drive Space
   If you wish to free some space on your hard drive, you can
   delete animations from the game.  1942 will detect that the
   animation files are missing, and continue to run normally
   The following files (and ONLY these files!) are O.K. to
   delete:

      OPEN.FLC    (1,563,324 bytes - 1942 title animation)
      MPSLOGO.FLC (  794,272 bytes - MicroProse animation)
      ANIM.CDF    (1,931,486 bytes - Carrier battle newsreels)

6. Virtual Cockpit Padlock Feature
   When you select the padlock feature from within the Virtual
   Cockpit, 1942 will lock on the enemy plane closest to the center
   of the screen.  The easiest way to padlock an enemy is to center
   the virtual cockpit view and use the gunsight to line up the
   enemy plane.

7. Carrier Battle 3-D Engagements
   If you abort out of a 3-D engagement before the mission is
   completed, the computer will finish the attack as if you had
   selected to observe.

   Keep in mind that, due to limitations in the number of planes
   that can be represented in 3-D, damage from large strikes will
   be a combination of the damage done in 3-D, and damage
   calculated statistically.  Your performance in 3-D, however,
   will have a limited effect upon the outcome of the statistical
   damage.

8. Realistic Flight Option
   The difference between realistic and non-realistic flight modes
   is quite significant.  We decided to combine all the realistic
   and potentially irritating problems that a pilot faces into this
   category.  The "purist" can select this mode to experience a 
   more accurate simulation of air combat, while the casual gamer
   can focus on the more "fun" elements.  Here is a list of probems
   added in this mode:

   - Engine torque will effect flight.
   - Planes will shake and break apart if flown too fast.
   - Engines will overheat and burn up if kept at max power.
   - Torpedos will fail if dropped at too high a speed or altitude.
   - Arrestor cables will be limited to the rear 1/3 of carrier.

9. Career Tailgunners
   After much debate within the design team, we decided not to
   allow you to enter the tailgunner during a career mission.  The
   reason is that while you are in the tail gunner the computer is
   flying the plane.  We feel that you must earn the points as a
   pilot, not as a passenger.

10. Japanese Radios (or Lack Thereof)
   The Japanese usually preferred not to carry radios in their
   aircraft due to their excessive weight.  Therefore, as a
   Japanese pilot, you will not receive the radio messages the
   Americans did in flight.

11. Scuttling Ships in a Carrier Battle
   When severely damaged ships slow a Task Group down to a degree
   that is dangerous to the remaining ships, you should scuttle the
   ship.  This was not an uncommon practice used to prevent the
   enemy from capturing the ship.  You can scuttle ships in the
   Damaged Ships option in the Taskgroup menu. Select a any
   displayed ship to scuttle.

FUTURE FEATURES:

Our development philosophy during 1942 has been to create the best
simulation of WW II air combat in existence.  We believe that these
air battles were some of the most exciting battles of any kind in
history, and an accurate representation of them would captivate
your interest for quite some time.  In order to achieve this goal
in only a year and a half, we were forced to leave some features
out that we would like to add in the future:

1. Modem play - we originally planned to have this feature in the
   initial release, so we are offering it as a free upgrade during
   the summer of 1994.

2. Digitized sound - at present, 1942 does not contain digitized
   sound.  We will be releasing an add-on product in summer or fall
   1994 with extensive digitized speech included.

3. More planes and more missions - we plan to release a scenario
   disk fall 1994.  It will focus on US Army Air Corps and Japanese
   Army air combat over New Guinea and the Phillipines.  We will
   include 6 new planes and hundreds of new missions in this
   scenario disk.

Technical Issues:

1. Thrustmaster WCS Mark II Support
   We have provided a configuration file for the WCS Mark II.  It's
   name is 1942PAW.ADV.  Consult your Thrustmaster documentation
   for instructions concerning how to upload this configuration.

2. Tandy Keyboard Problems
   If you are using a Tandy computer and are experiencing problems
   with the game not properly responding to game keystrokes, the
   'Alt' status of the keyboard has probably reversed.  That is,
   pressing 'A' results in an 'Alt-A' keystroke and vice-versa.
   To fix this problem, tap on the 'Alt' key until the status
   reverses back again.  We apologize for the inconvenience, but
   there seems to be something unique to the Tandy keyboard BIOS
   that causes this problem.  Our playtesters using Tandy machines
   report that this problem occurs infrequently and does not
   significantly detract from the enjoyment of 1942.  We will try
   to work with Tandy to solve this problem in a future update.

3. Bootdisk Problems
   In some Packard Bell computers, there may be a problem with the
   standard Microprose bootdisk application and some memory
   configurations. If you experience a lock up and you are using a
   bootdisk made by the 1942 install program, alter the config.sys
   file on the bootdisk from:
   
   Device=EMM386.EXE ramx=b0000-c400 /d=48 frame =e000 6800
   
   to (for DOS 5.0):
   
   Device=EMM386.EXE 2048 ram
   
   or to (for DOS 6.0 or later):
   
   Device=EMM386.EXE ram highscan
   
   If your hard drive is doublespaced, you are using the bootdisk,
   and you experience a problem, please add the following line to
   the end of the config.sys file on the bootdisk:
   
   Devicehigh= C:\DOS\DBLSPACE.SYS /move
   
********************
**** THANK YOUS ****
********************

Thanks to the following people who helped our playtest efforts:
   Bob Abe	
   Charlie Andaloro
   Jim Hendry
   Doug Whatley
	
