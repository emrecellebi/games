                      Game Crafters(TM) Presents

                         The Adventures
                               of
                         Maddog Williams(TM)
                               in

                    The Dungeons of Duridian(TM)

     Maddog Williams is an Interactive Animated Adventure Game (TM)
created by Game Crafters, a Spanish Fork, Utah based software house.

For installation and platform specific information please see the
accompanying install.txt file.

For more history of Maddog Williams and the lands of Duridian, see the novella
on our Maddog Williams web page at www.gamecrafters.com.

                         GETTING STARTED

     At first you will see the menu:

     Please Select Difficulty Level.
     1. Easy
     2. Hard
     3. Pray For Deliverance
     Selection:

     The level of difficulty affects the ease with which
you will be able to defeat the enemies and solve puzzles.
HARD and PRAY FOR DELIVERANCE use the same puzzles.

     Next you will see the prompt Change Options? (Y/N).  If you
select Yes then you will be asked what type of musical device you
have.  If you answer no to this question the default device is the
Computer Speaker.  After you select the musical device you can
answer No to this question the next time you play and it will
remember your selection. (If the game locks up right after this and
you don't have a sound card, try again and make sure you select
Computer Speaker.)

                         THE GAME BEGINS

      After the credits you will be greeted by the Guardian of
Marinor.  He will ask you "Is this your first time playing the
game? (Y) or (N)."  If you answer No the game will begin
immediately.  If you answer Yes you will see the introduction
sequence.  We suggest you watch the introduction at least once,  it
has information about the events leading up to the time the game
begins.  IMPORTANT!  When the Guardian asks you questions about the map
simply type in anything.  We have disabled the off-disk copy protection
for this release.

                            GAME PLAY

     After Maddog wakes up (Yes, adventurers always sleep on top of
the covers fully clothed!) you will be in control of him.  To move
him around the screen you can use the arrow keys, the number pad or
a joystick.  To switch between KEYBOARD and JOYSTICK mode, press
CTRL J.  An icon at the top of the screen will change between the
picture of a joystick and a key so you will know what mode you are
in.  The number pad allows 8-direction control of Maddog.
     To use the keyboard press the direction you wish to travel and
RELEASE the key.  Maddog will travel in that direction until you
press the same key again, or you press 5 on the keypad.  If you
press a different key, Maddog will change directions.  If you hold
the key down, Maddog will walk rather spastically.

     As you type in commands at the prompt and press Enter, a
response to what you typed will appear on the screen.  You must
press Enter to get rid of it!  Any other key will result in a
beep.  We do this so you won't miss any important texts that come
up automatically.

     During the game you will encounter enemies.  You must use
skill in fighting to defeat them.  To enter fight mode you must
first have a weapon, then press F1.  If an enemy is present (you
can tell because there will be a second Health-O-Meter at the top
of the screen just below Maddog's. If Maddog's health becomes blank,
he dies -- the same is true for enemies), Maddog will draw his sword
and prepare to fight.  If no enemy is present you will be asked if
you want to practice.  This allows you to practice fighting with
your current weapon.  To exit practice/fight mode press F1 again.

                            FIGHTING
KEYBOARD:

     SHIFT acts like the joystick button.

     LEFT & RIGHT arrows move Maddog Left and Right.

     UP arrow is like pressing up on the joystick.  If you press
SHIFT, Maddog will attack high.

     DOWN arrow is like pressing down on the joystick.  If you
press SHIFT, Maddog will attack low.  This also causes Maddog to
block the enemies' attack.  AFTER MADDOG BLOCKS, HE RETURNS TO
NEUTRAL.  You must press the down arrow key again to block.

     Key pad 5 is neutral (pressing the same direction twice will
return Maddog to neutral also).  If you press SHIFT, Maddog will
attack middle.

     If you swing while Maddog is moving backwards, HE WILL TURN
AROUND! This can be a very bad thing, as the enemy will attack
mercilessly. [Back stabbing %#@#$@#'s -- ed]

     Try the moves in practice mode to get a feel for how it works.

                      A SHORT WALKTHROUGH

     After Maddog is standing, type LOOK to give a
description of the surroundings.

     Type LOOK RUG and Maddog will describe the rug.

     Type LOOK UNDER RUG -- Maddog will walk to the rug and look
under it.

     Walk Maddog in front of the shelves. Type LOOK SHELVES.

     Type TAKE SWORD --Maddog will pick up his sword.

     Press F1, and practice with the sword a bit.

     Press F1 to exit practice mode.

                     A FEW FINAL SUGGESTIONS

     When you first enter a scene, type LOOK to get a description
of your surroundings.

     LOOK at everything imaginable.  Sometimes important clues are in
the text.

     If you meet someone, try to interact with them in some way.
TALK TO MAN is always a good way to start! (Unless it's not a man!)

     Fighting may seem hard at first, but hang in there --
you'll get used to it!

                      SPECIAL FUNCTION KEYS

F1 Toggles Fight MODE
F2 Help
F3 Retypes last line typed
F4 Saves the game
F5 Restores a saved game
F6 Sets Speed
F7 Shows Inventory
F8 Turns music off/on
F9 Restarts the game
F10 Quits
TAB Displays last text output
ESC Erases the input line.
SHIFT Acts like joystick button (Makes Maddog jump when walking
          around.  Attacks when fighting.)

We here at Game Crafters hope you enjoy playing the game.

Game Crafters, When it comes to games, we don't play around.

For further information, hints or questions, please visit our web page
at www.gamecrafters.com.

Please read the LICENSE.TXT file before playing the game.

Maddog Williams, Dungeons of Duridian, Game Crafters, and
Interactive Animated Adventure Game are trademarks of Game Crafters.

