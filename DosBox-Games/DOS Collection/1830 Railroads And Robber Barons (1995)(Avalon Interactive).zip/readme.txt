Copy protection:

The first time you play the game after installation, you will
be prompted to look up a word in the manual during the first
operating round.  Once this has been verified, you will never
need to worry about copy protection again unless you copy the
program to another machine or reinstall it.

---------------------------------------------------------------

Sound cards:

If you wish sound to work, be sure to configure the sound in
the SOUND.EXE program (which is automatically run at the end of
installation procedure, or you can run it yourself later to
change sound configuration).

BY DEFAULT, 1830 WILL BE CONFIGURED TO NOT USE SOUND.  You
should explicitly set which sound card you are using.

The utility program SOUND.EXE does not do hardware auto-detection.
It will look for a BLASTER environment variable having been
defined (by your AUTOEXEC.BAT typically), e.g.

set blaster=a220 i5 d1 t3

and derive address, IRQ, DMA values from that for the sound blaster.

-----------------------------------------------------------------

During the Auction of a Private Company Bidding Round, the mouths of
the Auctioneer and the Barons will move to indicate the placement
of a bid.  YOU WILL NOT HEAR DIGITIZED VOICES!!

------------------------------------------------------------------

Changing your mind about which Baron to play:

Hit ESCAPE if you decide you want to undo your click selecting
a Baron in a new game.

---------------------------------------------------------------

Quitting a game:

During a stock round, type 'Q' to quit.

During an operating round, you can click the 'QUIT' button on
the INFO popup.

---------------------------------------------------------------
Tech support:

You can reach Avalon Hill at:
1-410-426-9600 (Monday-Friday, 8:30am-5:00pm EST)


---------------------------------------------------------------

Saving disk space:

You may delete the file OPENING.LBX if you wish; this is
the opening animation of the train coming at you.  Deleting
this animation will free up about 4.5 MB of disk space.

---------------------------------------------------------------

Regenerating the same random map:

Whenever a random map is generated (by starting a game with the
random map option on), a file called LASTSEED is created in your
1830 directory.  If you like a random map and would like to
play it again, execute the DOS command:

  COPY LASTSEED READSEED

and then rerun 1830.  The program will read the random seed from
the file READSEED if it exists, thus repeating the same map again
for you instead of making a new random map.  You may save several
seed files with whatever other name you like, or write down the
seeds (you can TYPE LASTSEED; it's a plain text file) and create
READSEED yourself with a text editor.

----------------------------------------------------------------

QEMM note:
Some machines using QEMM with the stealth option won't be able
to run 1830.  If you have trouble running 1830 with QEMM, try
disabling stealth, or just use DOS's EMM386.EXE.

-----------------------------------------------------------------

CD-ROM version only:

When you install, you have 2 options:

(1) Install entire game on hard disk:
PROS: Faster to start program, doesn't require CD-ROM in drive to play
CONS: Takes up more hard disk space

(2) Install minimal files needed on hard disk:
PROS: Takes up less hard disk space
CONS: A little slower to start program, requires CD-ROM in drive to play

If you later decide to change your installation, you should delete
the 1830 files from your hard disk and rerun INSTALL from the
CD-ROM.  Don't attempt to simply copy or delete files yourself; it's
subtler than that.  (Save the file FAME if you wish to preserve your
Hall of Fame scores, and put it into the newly installed version
yourself if you wish.)

-----------------------------------------------------------------
