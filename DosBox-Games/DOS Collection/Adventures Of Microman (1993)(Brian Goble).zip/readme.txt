
                         The Adventures of MicroMan
                         ==========================

                        Adventure 1: Crazy Computers

                                Version 1.5

                     (Shareware - unregistered version)


                Programmed and Developed by: Brian L. Goble

                   Copyright (c) 1993-1994 Brian L. Goble



This Text file provides summary information.  For more detailed information
about this program, please refer to the MICRO1.TXT file.

MicroMan - Adventure 1, is an arcade-action style game for Windows 3.1
developed by Brian Goble using the Windows Animation Package (WAP) which was
also developed by Brian Goble.

The object of MicroMan is to run, jump, duck, climb and shoot your way past
the enemies while exploring new areas and collecting special powerups!

MicroMan - Adventure 1, is shareware.  Use beyond a 30 evaluation period
requires that you register this program with the author.  Registered users
will receive Adventure 2 of the MicroMan Adventure Series plus a special
bonus Windows application: WallMan.

You are free to distribute this program as long as all files are included
and no changes are made.  It is requested that shareware distributors
notify the author.


New Features for version 1.5 include:

   * Faster, Faster, Faster!
   * Save and Restore Game!
   * Background Music!
   * User Selectable Animation Speeds!
   * Better Collision Detection!
   * More Player Shots!
   * Better Sound Effects!


The MicroMan archive should contain the following files:

   * MICRO1.EXE
   * MICRO1.IMG
   * MICRO1.RMP
   * MICRO1.WAV
   * MICRO1.PG1
   * MICRO1.PG2
   * MICRO1.M01
   * MICRO1.M02
   * MICRO1.M03
   * MICRO1.M04
   * MICRO1.TXT
   * MICRO1.DLL
   * WAVEMIX.DLL
   * README.TXT
   * REGISTER.TXT


System requirements and recommendations for running MicroMan are:

   * Microsoft Windows 3.1    (required)
   * 4 megabytes of memory    (required)
   * 1.5 meg free disk space  (required)
   * 486 processor            (recommended)
   * 256 color graphics       (recommended)
   * Sound card               (recommended)


Quick Info:

   * Press F1 to view the "Quick Reference" help for MicroMan.
   * Fine tune the animation by selecting "Set Speed under the
     "Animation" menu.
   * All settings are saved in the MICRO1.INI file.
   * The keypad works best for game play--make sure Num-Lock is off.  Use
     your left hand to jump with the space-bar and place your right hand over
     the keypad, with your thumb on the Ins key for firing.


To install MicroMan, copy all the files (in the archive if you received
MicroMan in a compressed form) to any directory on your hard disk.

To play MicroMan, select "Run" from Program Manager's "File" menu and
enter the full path name (e.g. C:\WINDOWS\GAMES\MICRO1.EXE).  Alternatively,
you can double-click on the MICRO1.EXE file from File Manager.

See the MICRO1.TXT file for more information on MicroMan, registering, WAP,
and engine availability.


