POSLEDNI RADY
-----------------------------
Spustitelne pouze s 800kB EMS.
Pri problemech se spustenim ci provozem vypnete hudbu.
PC Speaker je poslouchatelny pouze s nastavenim nejrychlejsiho pocitace - VUBEC se vsak nedoporucuje
