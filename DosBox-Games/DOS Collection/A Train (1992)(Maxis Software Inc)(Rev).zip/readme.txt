
              README.TXT  -  LAST MINUTE ADDITIONS TO A-TRAIN

                          PLEASE READ CAREFULLY


     (Use the arrow keys or PageUp/PageDown to scroll through this file)



Generating a map (.PCX graphic image):

        Four lines will appear toward the top of the map and will seem to
shift in a pattern.  These lines are used by the program for generating a
.PCX file.  The screen will revert back to normal once the .PCX file is
completed.  In order to view this file, you will need to use a paint program
which supports the .PCX file format.


Working with an older version of the Logitech Mouse Driver:

        If you find yourself using a Logitech Mouse driver version 3.20 or
earlier, we recommend that you upgrade it through Logitech directly.  Having
such an early version of the mouse driver may cause some difficulties with 
the program.


Hercules users:

        The program will fail to function if run in 350 monochrome instead 
of standard Hercules mode.


Base Memory Requirements:

        You should have at least 520k of free base memory for the program
to run in color or monochrome modes.  Hercules requires about 550k free of
base memory. Just type CHKDSK at the DOS prompt to check your available
memory.  Also make sure that your files and buffers in your CONFIG.SYS
file are set to a minimum of 20.


Network Users: 

        If you are having some difficulties with awkward graphic glitches 
and random lock-ups, we recommend that you reboot your computer with a 
boot disk.  Once you have a DOS prompt, run A-Train again and you should 
be fine.


Keyboard Users:

        If you experience difficulties with your cursor keypad, be sure
that the "NumLock" on your keyboard is off.  Some keyboards may have a 
compatibility problem with A-Train.  If you are having some problem with 
your keyboard, press both the left and the right shift keys at once.  
This will reset the keyboard.


Laying Track:

        The cost for laying a section of track, assuming you own the 
land prior to construction, is 100 dollars instead of 300 dollars.
                                                                  

Holidays:

        As you go along and build your railroad fantasy, you will find that
there are certain days that SimPeople regard as important.  For example,
the advent of a new year will cause January 1st and 2nd to be classified as
holidays.  Holidays like this occur throughout the year as an added
dimension.

                An appreciation to our A-Train Engineers.

We hope that you will enjoy A-Train and all of its features to create your
own world.  A world in which you are the catalyst for change, but must also
rely on the A-Train simulator for creating an environment around your plans
for a metropolitan region.  Fun and challenge were two basic concepts that
went into the developement of A-Train.  Enjoy.

