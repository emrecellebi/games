
 Alien Cabal - Release Version 1.1
 ---------------------------------

 When it began few people noticed.  A near doubling of UFO sightings over
 the city.  But the local media dismissed them as hoaxes, military tests,
 or overzealous UFO fanatics.  They were wrong.

 The UFO's were real.  Alien's had been visiting for some time, studying
 mankind and earth's resources.  Now they were planning an invasion.

 After an investigation by secret government agencies a vast alien complex
 was discovered under the city. Fearing public reaction, an outbreak of a
 deadly new virus was faked to clear the city of its population.

 The press and media swarmed near the city.  A large scale military attack
 would be hard to explain and was ruled out.  No, what is needed is a one
 man army.  Someone trained in special operations, trained to run on raw
 courage, to kill without mercy, to eat things that would make a billygoat
 puke.  No, not him, I'm talking about you!

 Your mission is simple.  Find the entrance to the underground complex,
 exterminate all alien life, and destroy everything else.  Don't be fooled
 by what appear to be government agents.  These are clones programmed by
 the aliens to serve their purposes.

 Good luck,

 Now go get them!


 Compatibility
 -------------

 Alien Cabal is a DOS application.  It can be run from a DOS operating
 system or from a DOS box in Windows 95 or by restarting your Windows 95
 computer in MS-DOS mode.


 System Requirements
 -------------------

 * Pentium processor or equivalent.
 * A clock speed of 100Mhz or higher is recommended.
 * MS-DOS 5.0 or higher or Windows 95.
 * 16MB memory.
 * 45MB free hard drive space.
 * CD-ROM drive
 * Sound Blaster or compatible sound card recommended.
 * Joystick or mouse is optional.


 Installation and Setup
 ----------------------

 Before installing, make sure you have at least 45MB of hard disk space
 remaining.

 If running Windows 95, open a DOS box first.  Insert the Alien Cabal CD-ROM
 into your CD-ROM drive.  At the DOS prompt type the drive letter of your
 CD-ROM drive and a colon then press the Enter key (i.e. type D: and press
 Enter if your CD-ROM drive is the D drive). Type INSTALL and press the Enter
 key.  Follow the instructions on screen.

 Once all the files have been installed, change back to your hard drive by
 typing the letter of your hard drive and a colon then pressing the Enter key
 (i.e. type C: and press Enter if you installed Alien Cabal on the C drive).
 Type CD \ACABAL (or whatever directory you installed to) and press Enter.
 Now type SETUP and press Enter.  Change the settings to suit your preference
 and hardware.


 Creating a Desktop Shortcut in Windows 95
 -----------------------------------------

 If you have more than 16MB of memory you can run Alien Cabal in a Windows 95
 DOS box.  With only 16MB of memory you must restart in MS-DOS mode, so
 creating a shortcut doesn't really help much.

 To create a shortcut on the desktop, right click on the desktop and select
 New Shortcut.  This will bring up the shortcut wizard. Click on the browse
 button. In the browse window, click on the ACABAL directory (or whatever
 directory you installed to) then double click on the ACABAL.EXE file. Click
 on the Next button. Type "Alien Cabal" (no quotes) as the shortcut name and
 click on the Finish button.

 Now, right click on the Alien Cabal shortcut and select Properties. Click on
 the Screen tab. Select Full-screen in the Usage group. Also, if desired, you
 can change the shortcut's icon by clicking on the Program tab and then the
 Change Icon button. When you're done click the OK button.


 Starting Alien Cabal
 --------------------

 If running Windows 95 with more than 16MB of memory, double click on the
 Alien Cabal shortcut icon. If a shortcut was not created, then open a DOS
 box.  If the DOS box is not already full screen, click on the "full screen"
 button or press and hold the Alt key then press the Enter key.  Change to
 the directory where Alien Cabal was installed, type ACABAL and press the
 Enter key.

 If running Windows 95 with 16MB of memory, restart the computer in MS-DOS
 mode, change to the directory where Alien Cabal was installed, type ACABAL
 and press the Enter key.

 If running DOS, change to the directory where Alien Cabal was installed,
 type ACABAL and press the Enter key.

 If you have only 16MB of memory and are running DOS and/or Windows 3.1,
 you may want to create a bootable floppy (see your DOS documentation) with
 a CONFIG.SYS and AUTOEXEC.BAT stripped down to the minimum.  One thing to
 avoid in particular on Windows 3.1 systems is loading SMARTDRV.  This is a
 disk buffering driver which typically takes up more than 2MB of memory.

 If you see "Zone buffer = 12000000 bytes" when Alien Cabal is starting up
 (just after the "Preloading" is done) then you have enough memory.  Anything
 less and some larger levels may fail to load with an error message like
 "ERROR: Out of zone buffer memory".


 Starting a New Game
 -------------------

 If a game is already in progress, press the Esc key to bring up the main
 menu.  Use the up and down arrow keys to select New Game then press the
 Enter key.  Select one of the skill levels and press Enter to start the
 game.  Choosing a higher skill level results in more aggressive and more
 numerous life forms.  If you're new to 3D action games, choose the first
 skill level listed.  If the game seems too easy, start a new game and
 select a higher skill level.


 Saving a Game
 -------------

 A game can be saved at any point during game play.  It's a good idea to
 save your game often, just in case you walk into a trap and get wasted.
 To save the game in progress, press the Esc key to bring up the main menu.
 Use the up and down arrow keys to select Save Game and press the Enter key.
 Select the slot where the game is to be saved.  Any existing game saved in
 that slot will be overwritten.  Type in a name for the game saved and press
 the Enter key.  Up to six games can be saved.  To abort the Save Game
 operation press the Esc key.


 Loading a Saved Game
 --------------------

 If a game is already in progress, press the Esc key to bring up the main
 menu.  Use the up and down arrow keys to select Load Game and press the
 Enter key.  Select the slot where the game was saved and press the Enter
 key.  To abort the Load Game operation press the Esc key.


 Pausing the Game
 ----------------

 If a game is in progress, press the Pause key to pause the game.  Press the
 Pause key again to continue game play.


 Quitting the Game
 -----------------

 If a game is already in progress, press the Esc key to bring up the main
 menu.  Use the up and down arrow keys to select Quit and press the Enter key.


 Help Screens
 ------------

 If the main menu is displayed, use the up and down arrow keys to select
 Help and press the Enter key.  If a game is in progress press the F1 key.


 Sound Volume
 ------------

 Press F9 to lower the sound volume and F10 to raise it.  If running Alien
 Cabal from a DOS box in Windows 95, the volume controls in Windows 95 will
 also affect the sound volume in Alien Cabal.


 Mouse Sensitivity
 -----------------

 Mouse sensitivity controls are only active during game play.  There are
 sensitivity controls for player rotation and motion.  Press F5 to lower
 rotational sensitivity and F6 to raise it.  Press F7 to lower motion
 sensitivity and F8 to raise it.  Motion sensitivity only affects the
 motion created by moving the mouse, not the motion caused by pressing
 the "move forward" mouse button.


 Player Controls
 ---------------

 Alien Cabal can be played with the keyboard alone or in combination with a
 mouse or joystick.  The SETUP program determines which of these combinations
 is used.  While playing the game, press the F1 key to get help for the player
 controls.


 Player Motion
 -------------

 Using the keyboard the player can move forward and backward, turn left and
 right, and look up and down by pressing the appropriate key.  There is also
 a "move faster" key which moves the player twice as fast as normal.

 The mouse can be used to move forward and backward or turn left and right
 by simply moving the mouse.  One of the mouse buttons can also be configured
 to cause forward motion. Another mouse button can be configured to act as
 the fire button.  There is no "activate" assignment available for the mouse
 (use the keyboard to open doors and activate lifts).

 The joystick allows proportional motion control for moving forward and
 backward, or turning left and right.  It can also be used to look up and
 down by pressing and holding the appropriate joystick button and moving
 the joystick forward and backward.  Other buttons on the joystick can
 be configured to act as the fire button, the "look forward" button, or
 the "activate" button.


 Looking Up and Down
 -------------------

 It's a good idea to take a careful look around when entering an unexplored
 room, but looking up and down is also used to line up a shot or toss a
 grenade down a hole or up into a open window or doorway.


 Map Mode
 --------

 Pressing the map mode key during game play stops all game action and enters
 the map mode.  In this mode you see any polygons which you have walked on.
 The more you explore, the bigger the map gets.  The map initially shows a
 view from above your current position looking straight down, unless
 "retain map position" is on (press R to toggle).  You can move around the
 map or look up and down just as in the game, except you're basically flying.
 You can fly up or down and pass through polygons.


 Status Bar
 ----------

 At the bottom of the screen is a status bar showing your health level, armor
 level, weapons collected, ammo counts, and keys collected.  Your health level
 starts at 100 percent.  When it reaches 0, its all over.  Armor helps block
 enemy attacks, but eventually wears out.  Weapons are indicated numerically.
 The pistol is 1, shotgun 2, machine gun 3, grenades 4, and bazooka 5.  The
 ammo indicators show bullets, shells, grenades, and rockets respectively.
 The green, yellow, and red keys appear in the keys section when collected.


 Objects
 -------

 Throughout the environment you will find various objects that may be of use
 to you.  To pick up an object just walk directly toward it.  When you get
 close enough you will automatically pick it up, unless you don't need it
 (in the case of health kits or armor) or can't carry any more (in the case
 of various ammunition supplies).  Be on the lookout for keys.  These are
 needed to operate most doors and some lifts.  There is a brief message at
 the top of the screen to indicate what you picked up.


 Weapons
 -------

 There are five weapons available to the player.  They include a pistol,
 shotgun, machine gun, grenades, and bazooka. The pistol fires one round at
 a time, but is very accurate.  The shotgun is a powerful weapon and can take
 out most creatures with one shot at close range, but is much less effective
 at greater distances.  The machine gun fires rapidly but is not very accurate
 at a distance.  Grenades are useful for clearing out a room before entering
 or taking out a cluster of aliens.  Remember, grenades can be bounced off
 walls, floors, and ceilings or tossed into open doorways or windows.  Of
 course, the bazooka is the ultimate weapon of destruction, just be careful
 not to shoot something too close or you'll get caught by the blast!


 Lining Up Your Shot
 -------------------

 There is no automatic target aiming in Alien Cabal.  Your shot goes where
 you aim and that's it.  The center of the screen is your aiming point.
 Most of the time aliens or other creations can be shot while looking
 straight forward and rotating left or right until the shot is lined up,
 but sometimes they may be above or below you.  To line up these shots,
 you need to look up or down using the keyboard or joystick.  To look
 straight forward again, press the appropriate joystick button or
 keyboard key.


 Doors, Lifts, and Switches
 --------------------------

 To open a door or activate a lift press the activate button (if using a
 joystick) or the activate key (if using the keyboard).  Some lifts are
 automatically activated when stepped on.  Most doors and lifts return to
 the original position after a predetermined time delay.  Those that don't
 must be activated again to cause them to return to their original position.
 Of course most doors and some lifts require that you possess a particular
 key.  If you don't have the key nothing happens.  The required key color
 is usually indicated on or near the door or lift.  Some lifts are operated
 by a nearby switch while others are activated directly.


 Secrets
 -------

 There are usually one or more secret areas in each level.  If you're paying
 attention you should be able to find the secret areas, but they are not
 required to accomplish your mission.


 Completing a Level
 ------------------

 When a level is completed you will get a screen of statistics showing how
 well you did in that level.  A perfect score is 100 percent on everything.
 This  isn't easy to do.  To get a perfect score you must kill everything
 alive, destroy everything destructible, pick up all useful items, and find
 all secret areas.


 Cheat Codes
 -----------

 During game play the following codes are recognized:

 acgodmode     Toggle "god mode"
 acallkeys     Gives the user all keys
 acallweapons  Gives the user all weapons available on the current level
 acallmap      All polygons shown in map mode.
 acwarpxx      Warp to level xx (i.e. acwarp03 would warp to level 3)
 acnoclip      Walk through walls.
 acsavepos     Save the current position.
 acloadpos     Go to the last saved position.
 achealth      Get 100% health.
 ackill        Kill any monster in line of sight.
 acundead      Respawn all monsters.
 acstatus      Show status overlay.
 acmemory      Show memory usage.

 The following codes can be used on the command line:

 -godmode      Activate "god mode".
 -allkeys      Gives the user all keys.
 -allweapons   Gives the user all weapons available at each level.
 -allmap       All polygons shown in map mode.
 -warpx        Warp to level x (i.e. -warp3 would warp to level 3).
 -skillx       Set default skill to x (use with warp command).
 -nomonsters   No monsters.


 Build Mode
 ----------

 If you create your own levels using VEdit (see the vedit.txt file) they are
 ready to play immediately.  However, if the your level is large and complex,
 with many rooms and walls, it may run slowly in some situations. To overcome
 this problem there is a way to optimize a level.  Once a level is optimized
 only the things which are visible from the polygon the player is currently
 standing on are displayed, resulting in faster game play. Build mode is used
 to setup these visibility lists.

 To enter build mode use the following set of command line options:

 -build        Enable build mode.
 -allkeys      To open doors with.
 -allweapons   So you can break windows, etc (to see through them).
 -warpx        Warp to level x (if optimizing a multi-level GOB file).
 -nomonsters   Monsters just get in the way in build mode.
 -noautoreturn All doors, lifts, etc. are manually activated.
 -nograb       Don't pick up anything (can't see them if they get picked up).
 -fly          Enable flying (PgUp to go up, Ins to go down, Home to drop).

 Use the following one-key functions (only enabled with -build option):

 B ........... Enter build mode. Add anything seen to current visibility list.
 N ........... Reset current visibility list (rarely needed).
 O ........... Enter build mode, look all around, then exit build mode.
 V ........... Switch view mode (solid only, solid + wire, wire only).
 S ........... Save the current position (same as acsavepos).
 R ........... Go to last saved position (same as acreadpos).
 F4 .......... Show current polygon with wire frame (under the player).

 To optimize a GOB file start ACABAL with the command line parameters shown
 above plus the name of your GOB file.  Select New Game from the main menu.
 When the game starts the first thing you should do is press the F4 key.
 This puts a wire frame border on the current polygon (the one being
 optimized, the one your standing on).

 There are two ways to optimize.  The B key is a build mode toggle. When it
 is enabled the Build keyword is shown in the lower left and anything you see
 gets added to the visibility list of the current polygon.  While in build
 mode you will probably notice a slowdown in the game.  This is due to the
 additional overhead associated with doing visibility tests.  You could just
 run around in build mode like this until your sure you looked at everything
 from every polygon, but this is usually too slow.  Its faster to use the O
 key at each corner of the current polygon and at any junctions with other
 polygons.

 If you notice something missing (missing polygons usually cause a "hall of
 mirrors" effect), just enter the build mode temporarily by pressing the B key
 twice (or the O key once) while looking in the direction where the missing
 thing should be.

 When you're done optimizing, press Esc to bring up the main menu, then select
 Quit.  If any visibility lists have changed a new GOB file will be written.
 The file name will be NEWXXXXX.GOB, where XXXXX is the next sequential number
 which is available.  To continue optimizing, put this file name on the
 command line.  When all done, delete the original GOB file and rename the
 last generated NEWXXXXX.GOB file to the original GOB file name.  Finally,
 delete any leftover NEWXXXXX.GOB files.  If more optimization is required,
 the entire process can be repeated.


 Default Keyboard Configuration
 ------------------------------

 This is the default keyboard configuration.  Many of these can be redefined
 using the SETUP program.

 Esc   = Main menu
 Pause = Pause game

 F1    = Help
 F3    = Take screen shot (saved as BMP file)
 F5    = Mouse rotation sensitivity down
 F6    = Mouse rotation sensitivity up
 F7    = Mouse motion sensitivity down
 F8    = Mouse motion sensitivity up
 F9    = Volume down
 F10   = Volume up

 Tab   = Map mode
 <     = Map zoom in
 >     = Map zoom out
 R     = Retain map position

 Ctrl  = Fire
 Space = Activate
 Up    = Move forward
 Down  = Move backward
 Shift = Move faster
 Left  = Turn left
 Right = Turn right
 Del   = Look down
 End   = Look forward
 PgDn  = Look up

 0     = No weapon
 1     = Pistol
 2     = Shotgun
 3     = Machine gun
 4     = Grenade
 5     = Bazooka


 Credits
 -------

 Software Engineering        Greg Taylor

 Level Design                Chris Kendall
                             Greg Taylor
                             Phillip McNeely

 Graphics Design             Chris Kendall

 3D Character Design         John Kubasco

 Sound Effects               Richard Cruz, Jr.
                             Chris Kendall

 Music                       Richard Cruz, Jr.


 Visit us on the web at www.aliencabal.com


 -----------------------------------------------------------------------
 Alien Cabal (c) 1997 QASoft.  All rights reserved.  Microsoft, MS-DOS,
 Windows and the Windows Logo are registered trademarks of Microsoft
 Corporation.  All other trademarks are the property of their respective
 companies.
 -----------------------------------------------------------------------

